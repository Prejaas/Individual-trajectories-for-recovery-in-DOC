
<p align="center">
  <img width="680" height="150" src="https://github.com/BrainDynamicsUSYD/braintrak/blob/master/docs/img/braintrak_logo.png">
</p>


_Real-time brain states tracking and corticothalamic neural field model parameter estimation_


#### Getting started
The documentation in [BrainTrak's wiki](https://github.com/BrainDynamicsUSYD/braintrak/wiki)

#### Other relevant sofware
Mutiscale neural field simulations
[NFTsim](https://github.com/BrainDynamicsUSYD/nftsim)
