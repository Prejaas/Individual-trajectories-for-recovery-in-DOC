The files in this folder were used to generate some of the fits in Abeysuriya 2015 (Real-time automated EEG tracking of brain states using neural field theory).

fit_cluster.m - Fit full sleep night data
fit_br_bic.m - Calculate the AIC/BIC etc. for the model comparison
