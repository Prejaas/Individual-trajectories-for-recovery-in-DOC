function m = generate_matfile_options(fname, p, inopts)
% DESCRIPTION:  generate the file to run parameter sweeps 
% ARGUMENTS:
%         fname             -- string to append to file name
%         p                 -- params structure
%         inopts.blocks            -- number of iterations for the outer
%                                     for loop in parameter_sweep.
%                                     Required to avoid memory issues.
%         inopts.interval          -- step to generate a range 
%         inopts.these_axes        -- axes to explore fully
%         inopts.slice_values(optional)      -- parameter values of the specific
%                                                slice in the axes that are not completly explored
% OUTPUT: 
%         m  -- handle to writable matfile
%
% REQUIRES:
%        
% USAGE:
%{

fname = 'local_test';
inopt.interval = 1e-2;
inopt.blocks = 4;
inopt.these_axes = [1, 2, 3, 4];   % explore only the first four dimensions
inopt.slice_values = [0, 0, 0, 0]; % set to zero other parameters

% generate the file
m = utils.io.generate_matfile_options(fname, ss, inopt);

% or 
inopt.these_axes = 1:8;   
inopt.slice_values = []; 
mm = utils.io.generate_matfile_options(fname, ss, inopt);

%}
% TODO: handle cases that will yield errors 

% Create file to store results
date_string = 'yyyy-mm-dd';
filename    = strcat(datestr(now, date_string), fname);
m           = matfile(filename,'Writable',true);

% get nu ranges, whole axes or just slices across dimensions
if ~isempty(inopts.slice_values)
    [nus, ox] = parsweep.get_nu_ranges(p, inopts.interval, inopts.these_axes, inopts.slice_values);
    options.axes.unselected = ox;
else
    [nus] = parsweep.get_nu_ranges(p, inopts.interval, 1:8);
    options.axes.unselected = []; 
end

% maybe consider getting slice indices as well, that is, if we were to
% explore all the dimensions, we would take the parameter value of the m-th 
% slice along the n-th axis.
options.axes.slice_values = inopts.slice_values;
options.axes.labels = {'\nu_{ee}', '\nu_{ei}', '\nu_{es}', '\nu_{se}', '\nu_{sr}', '\nu_{sn}', '\nu_{re}', '\nu_{rs}'};
    
%
options.iteration.blocks = inopts.blocks;
options.interval = inopts.interval;
options.axes.selected = inopts.these_axes;
options.errors.correct_results = 0;


% write something to it
m.options = options;
m.nus = nus;

end