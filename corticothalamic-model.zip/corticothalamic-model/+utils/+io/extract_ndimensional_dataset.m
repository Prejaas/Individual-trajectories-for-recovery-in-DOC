% Extracts n-dimensional dataset from an p-dimensional dataset (n < p)
% n should be 3 or 4, since they are safest options to avoid memory errors
% ARGUMENTS:
%         m              -- handle to writable matfile 
%         extract_ax     -- a 1xn vector specifying  which axes should be
%                           extracted
%         extract_slices -- an 1 x (p-n) row vector with the slice numbers from 
%                           the axes that are not in extract_ax;
%         this_field     -- a string to decide which variable to read from
%                           m.
% OUTPUT: 
%         cube           -- a struct with the data and other info
%
% REQUIRES:
%         None!
%        
% USAGE:
%{   
    myfile =  matfile('myfile.mat')
    cube   =  utils.io.extract_ndimensional_dataset(myfile, [3, 5, 6], [1, 1, 1, 1, 1])
%}
%
% PSL Feb 2016
% TODO: generalize this function by given the name of the field to extract,
% the name of the output field in cube, append to cube if cube already
% exists.

function cube = extract_ndimensional_dataset(miofile, extract_ax, extract_slices, this_field)


options = miofile.options;

[nax, ndim]  = deal(length(options.shape.nroot_full_shape), options.shape.nroot_full_shape);

if length(extract_ax) + length(extract_slices) > nax
    error('Trying to get data from dimensions than are not available')
end

nax_e = length(extract_ax);

% size along each of the axes to extract
nn = zeros(nax_e, 1);
for k = 1:nax_e
    nn(k) = ndim(extract_ax(k));
end

% subscripts 
idx = ones(nax, prod(nn));

if nax_e == 1
    [x] = ndgrid(1:nn(1));
    idx(extract_ax(1), :) = x(:);
elseif nax_e ==2
    [x, y] = ndgrid(1:nn(1), 1:nn(2));
    idx(extract_ax(1), :) = x(:);
    idx(extract_ax(2), :) = y(:);
elseif nax_e == 3
    [x, y, z] = ndgrid(1:nn(1), 1:nn(2), 1:nn(3));
    idx(extract_ax(1), :) = x(:);
    idx(extract_ax(2), :) = y(:);
    idx(extract_ax(3), :) = z(:);
elseif nax_e == 4
    [x, y, z, w] = ndgrid(1:nn(1), 1:nn(2), 1:nn(3), 1:nn(4));
    idx(extract_ax(1), :) = x(:);
    idx(extract_ax(2), :) = y(:);
    idx(extract_ax(3), :) = z(:);
    idx(extract_ax(4), :) = w(:);
end

% select the proper slices
idx(setxor(extract_ax, 1:nax), :) = repmat(extract_slices', [1, prod(nn)]); 

%linear indices obtained from 8-dimensional subscripts
v   = sub2ind(ndim,idx(1, :), idx(2, :), idx(3, :), idx(4, :), ...
                   idx(5, :), idx(6, :), idx(7, :), idx(8, :));
v = v';
data = nan(length(x(:)),1);

% Check that v is equally spaced
% Find places when contiguous blocks finish
idx1 = find(diff(v)> 1);
idx2 = idx1 + 1;
idx1 = [idx1; length(v)];
idx2 = [1; idx2];

% start:stop indices of contiguous blocks
idx = [idx2 idx1];

switch this_field
    case 'nroots'
        % make root data them 8-bit integers
        data     = uint8(miofile.nroots(v,1));
        bad_root = miofile.bad_root(v,1);
   case 'stab_nroots'
        % make root data them 8-bit integers
        data     = uint8(miofile.nroots(v,1));
        stab     = miofile.stab(:, :, v);
        cube.stab = reshape(stab, [1,    5, ndim(extract_ax)]);
        clear stab
    case 'bif'        
        % make root data them 8-bit integers
        % This will work as long as indices in v are contiguous.
        
        try % try to get everything at once
            % It can't it'd give the following error:
            % Cannot index into 'nroots' because ranges for MatFile objects must increase in equally spaced intervals.
            data = uint8(miofile.nroots(v,1));
            stab = miofile.stab(:, :, v);
            phia = miofile.phia(:, :, v);
            bad_root = miofile.bad_root(v,1);
        catch % otherwise get blocks of consecutive values
            for bb = 1:length(idx)
                data(idx(bb,1):idx(bb, 2), 1)    = uint8(miofile.nroots(v(idx(bb,1):idx(bb,2)),1));
                stab(:, :, idx(bb,1):idx(bb, 2)) = miofile.stab(:, :,   v(idx(bb,1):idx(bb,2)));
                phia(:, :, idx(bb,1):idx(bb, 2)) = miofile.phia(:, :,   v(idx(bb,1):idx(bb,2)));
                bad_root(idx(bb,1):idx(bb, 2),1) = miofile.bad_root(v(idx(bb,1):idx(bb,2)),1);
            end
        end
        cube.phia = reshape(phia, [5,    3, ndim(extract_ax)]);
        cube.stab = reshape(stab, [1,    5, ndim(extract_ax)]);
        clear phia stab
        
    case 'power'
        % make root data them 8-bit integers
        % This will work as long as indices in v are contiguous.
        
        try % try to get everything at once
            % It can't it'd give the following error:
            % Cannot index into 'nroots' because ranges for MatFile objects must increase in equally spaced intervals.
            data = uint8(miofile.nroots(v,1));
            stab = miofile.stab(:, :, v);
            phia = miofile.phia(:, :, v);
            fpeaks   = miofile.fpeaks(:, :, v);
            pe   = miofile.pe(:, :, v);
            bad_root = miofile.bad_root(v,1);
        catch % otherwise get blocks of consecutive values
            for bb = 1:length(idx)
                data(idx(bb,1):idx(bb, 2), 1)    = uint8(miofile.nroots(v(idx(bb,1):idx(bb,2)),1));
                stab(:, :, idx(bb,1):idx(bb, 2)) = miofile.stab(:, :,   v(idx(bb,1):idx(bb,2)));
                phia(:, :, idx(bb,1):idx(bb, 2)) = miofile.phia(:, :,   v(idx(bb,1):idx(bb,2)));
                pe(:, :, idx(bb,1):idx(bb, 2))   = miofile.pe(:, :,   v(idx(bb,1):idx(bb,2)));
                fpeaks(:, :, idx(bb,1):idx(bb, 2))   = miofile.fpeaks(:, :,   v(idx(bb,1):idx(bb,2)));
                bad_root(idx(bb,1):idx(bb, 2),1) = miofile.bad_root(v(idx(bb,1):idx(bb,2)),1);
            end
        end
        cube.phia = reshape(phia, [5,    3, ndim(extract_ax)]);
        cube.pe   = reshape(pe  , [5, 1000, ndim(extract_ax)]);
        cube.fpeaks = reshape(fpeaks, [5,    2, ndim(extract_ax)]);
        cube.stab = reshape(stab, [1,    5, ndim(extract_ax)]);
        clear phia stab

        
    case 'gab'
        try % try to get everything at once
            % It can't it'd give the following error:
            % Cannot index into 'nroots' because ranges for MatFile objects must increase in equally spaced intervals.
            data = uint8(miofile.nroots(v,1));
            gab = miofile.gab(:, :, v);
            xyz = miofile.xyz(:, :, v);
            bad_root = miofile.bad_root(v,1);
        catch % otherwise get blocks of consecutive values
            for bb = 1:length(idx)
                data(idx(bb,1):idx(bb, 2), 1)    = uint8(miofile.nroots(v(idx(bb,1):idx(bb,2)),1));
                gab(:, :, idx(bb,1):idx(bb, 2))  = miofile.gab(:, :,   v(idx(bb,1):idx(bb,2)));
                xyz(:, :, idx(bb,1):idx(bb, 2))  = miofile.xyz(:, :,   v(idx(bb,1):idx(bb,2)));
                bad_root(idx(bb,1):idx(bb, 2),1) = miofile.bad_root(v(idx(bb,1):idx(bb,2)),1);
            end
        end
        cube.gab = reshape(gab, [5, 8, ndim(extract_ax)]);
        cube.xyz = reshape(xyz, [5, 3, ndim(extract_ax)]);
        clear gab xyz
end

% reshape into the right dimensions
if nax_e > 1
    cube.data = reshape(data, ndim(extract_ax));
    %cube.bad_root = reshape(bad_root, ndim(extract_ax));
else
    cube.data = data;
    cube.bad_root = bad_root;
clear data
cube.axes.extract_ax = extract_ax;
cube.axes.slices     = extract_slices;

% write the result to the file
if miofile.Properties.Writable
    miofile.cube = cube;
end

end
