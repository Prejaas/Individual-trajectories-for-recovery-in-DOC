%% Plot the 1d manifold of stable and 
% unstable solutions for the corticothalamic model's steady state equation.
%
% ARGUMENTS:
%        p      -- @params class/object with nominal parameters of some brain state 
%        nu_idx -- an integer, the index of the nu_ab acting as the driving
%                  parameter.
%                  1: nuee; 
%                  2: nuei; 
%                  3: nues; 
%                  4: nuse; 
%                  5: nusr; 
%                  6: nusn; 
%                  7: nure; 
%                  8: nurs.
%        options -- a struct to control basic properties of line plot
% OUTPUT: 
%        fn_imp -- ImplicitFunctionLine -- Matlab's type
%        ax_hn  -- Axes handles
%        fig_hn -- figure handles
% USAGE:
%{
     load('seizure_parameters.mat')
     nu_idx = 4;
     [fn_imp, ax_hn, options] =  utils.viz.plot_steady_state_1d_manifold(absz, nu_idx, []);
     
     % Overlay unstable branch
     hold on;
     options.yrange = [3.2, 249.];
     options.color = [1 0 0];
     options.display_name = 'unstable';
     [fn_imp, ax_hn, options] =  utils.viz.plot_steady_state_1d_manifold(absz, nu_idx, options);
     
     % Set labels
     ax_hn.XLabel.String = '\nu_{se} [V s]';
     ax_hn.YLabel.String = '\phi_{ee} [s^{-1}]'

    % Save the figure
    savefig(gcf, 'plot_steady_state_1d_manifold.fig', 'compact')

end
      
%}
% REQUIRES: 
%         corticothalamic-model
%
% TODO: 
%      generalize in case qmax and sigma_prime are actually different for different populations
%          
% MODIFICATION HISTORY:
%     PSL(<27-11-2017>) -- Original. Tested on malab 2016b.
function [fn_imp, ax_hn, options] = plot_steady_state_1d_manifold(par, nu_idx, options)
%
nus   = par.nus;
qmax  = par.qmax;
theta = par.theta;
sigma_prime   = par.sigma;

if isempty(options)
    options.color = [0, 0, 0];
    options.line_width = 2;
    options.display_name = 'stable';
    options.yrange = [0, qmax];
    options.xrange = [par.range_nus(1,nu_idx), par.range_nus(2, nu_idx)];
    options.mesh_density = 512;
end

% activation function: sigmoid
sigmoid = @(ve) model.sigm(ve, theta, sigma_prime, qmax);
% inverse of activation function
sig_inv = @(qe) model.sinv(qe, theta, sigma_prime, qmax);

% make variables related to the model symbols
nuee = nus(1);
nuei = nus(2);
nues = nus(3);
nuse = nus(4);
nusr = nus(5);
nusn = nus(6);
nure = nus(7);
nurs = nus(8);

% Eq. (31) Sanz-Leon and Robinson. 2017 - Journal of Theoretical Biology      
fqe = {@(nuee, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nuei, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nues, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nuse, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nusr, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nusn, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nure, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe)))))), ...
       @(nurs, qe) (sig_inv(qe)) - (nuee+nuei).*qe - nues.*(sigmoid((nuse.*qe + nusn + nusr.*sigmoid((nure.*qe+nurs/nues .* (sig_inv(qe) - (nuee+nuei).*qe))))))};         



ax_hn  = subplot(1,1,1);
fn_imp = fimplicit(fqe{nu_idx}, 'MeshDensity', options.mesh_density);

% Default
fn_imp.XRange = options.xrange;
fn_imp.YRange = options.yrange;
fn_imp.Color       = options.color;
fn_imp.LineWidth   = options.line_width;
fn_imp.DisplayName = options.display_name ;

end
% EOF
