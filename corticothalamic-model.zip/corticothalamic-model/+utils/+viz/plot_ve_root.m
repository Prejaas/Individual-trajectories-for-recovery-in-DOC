%% Plots the transcendental equation (model.ve_root) used to obtain steady-states
%  
% ARGUMENTS:
%         p   -- is a params structure with parameters for the
%                corticothalamic model
%         idx -- is the index of the specific set in p or a vector of indices. 
%         ve  -- is a range of Ve values.
%
% OUTPUT: 
%         h --  handle to line object
%
% REQUIRES: 
%        model.ve_root
%        
% USAGE:
%{   load('example_parameters.mat')
%    utils.plot_ve_root(ec, 1, -0.04:0.0001:0.04)
% or
%    utils.plot_ve_root(ec, 1, [])
%}
%
function h = plot_ve_root(p, idx, ve)
% Plots the formula in  against a predifined range of ve
% p is a params structure
% idx 

if nargin < 2
    idx = 1;
    ve  = linspace(-0.04,0.04,1e5);
end

if isempty(ve),
    ve = linspace(-0.04,0.04,1e5);
end
% 

idx_length = length(idx);

hold on;
for i = 1:idx_length
      y = model.ve_root(ve,p(idx(i)).nus,p(idx(i)).theta,p(idx(i)).sigma,p(idx(i)).qmax);
      this_black = (i-1) / idx_length;
      h = plot(ve, y, 'color', this_black*ones(1,3),'linewidth',1);      
      % Plot stable fixed points
      stab_idx = find(p(idx(i)).stab);
      plot(p(idx(i)).ve(stab_idx), zeros(length(p(idx(i)).ve(stab_idx)),1),'ko', 'markersize', 7, 'markerfacecolor', 'k', 'linewidth', 2)
      % Plot unstable fixed points
      unstab_idx = find(p(idx(i)).stab < 1);
      plot(p(idx(i)).ve(unstab_idx), zeros(length(p(idx(i)).ve(unstab_idx)),1),'ko', 'markersize', 7, 'markerfacecolor', 'white', 'linewidth', 2)

      
end

lims = axis;
plot([lims(1) lims(2)], [0 0], ':', 'color', [0 0 0]);%[0 0.447058826684952 0.74117648601532])
xlabel('V_e [V]')
ylabel('g(Ve)')
%title('Steady state equation g(V_e)')
xlim([ve(1) ve(end)])
end