function x = isfunction(h)
	x = isa(h,'function_handle');
end