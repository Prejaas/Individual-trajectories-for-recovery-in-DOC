function test_rfft
	% See Chris Rennie's FFT notes for tests

	t = 0:0.002:4-0.001; % 4 seconds at 500Hz
	A = 3;

	% Chris's tests
	x_delta = zeros(size(t)); x_delta(t==0.2) = 3;
	x_sine = 3*cos(2*pi*t*3); 
	x_noise = 3*randn(size(t));

	% Time series checks
	isnear = @(a,b) assert(all(abs(a-b)<1e-6)); % Check equal within tolerance

	isnear(sum(x_delta.^2)/length(x_delta),0.0045)
	isnear(sum(x_sine.^2)/length(x_sine),4.5)

	% CHECK BASIC FFT RESULTS

	y_delta = fft(x_delta)/length(x_delta);
	y_sine = fft(x_sine)/length(x_sine);
	y_noise = fft(x_noise)/length(x_noise);

	% Delta function, all components are the same
	assert(max(abs(abs(y_delta)-0.0015)) < 1e-8) % delta function, all components should be the same

	% Frequency resolution of 1/4=0.25Hz
	% thus for y_sine, the nonzero component should be at 3Hz = bin 13
	isnear(y_sine(12),0)
	isnear(y_sine(13),1.5)
	isnear(y_sine(14),0)
	isnear(y_sine(end-10),0); % offsetting both the zero and the nyquist, so 11 instead of 13
	isnear(y_sine(end-11),1.5); % offsetting both the zero and the nyquist, so 11 instead of 13
	isnear(y_sine(end-12),0); % offsetting both the zero and the nyquist, so 11 instead of 13

	% The energy should have known values
	isnear(sum(abs(y_delta.^2)),0.0045)
	isnear(sum(abs(y_sine.^2)),4.5)
	isnear(sum(abs(x_noise).^2)/length(x_noise),sum(abs(y_noise).^2))

	% NOW TEST SAME RESULTS WITH SINGLE SIDED SPECTRUM
	[f,~,P_delta] = utils.rfft(x_delta,1/t(2));
	[f,~,P_sine ] = utils.rfft(x_sine ,1/t(2));
	[f,~,P_noise] = utils.rfft(x_noise,1/t(2));

	delta_f = 1/(t(2)*length(t)); % theoretical frequency step size
	assert(f(3/delta_f+1)==3) % 3Hz bin

	isnear(P_delta(1),0.0015.^2/delta_f)
	isnear(P_delta(2),2*0.0015.^2/delta_f)
	isnear(P_delta(end),0.0015.^2/delta_f)
	
	% Note trapz(f,P) is not *quite* exact. Off by about 2e-6
	isnear(sum(P_delta)*delta_f,0.0045) 
	isnear(sum(P_sine)*delta_f,4.5)
	isnear(P_sine(13)*delta_f,4.5)
	isnear(sum(abs(x_noise).^2)/length(x_noise),sum(P_noise)*delta_f) % numerical issues with trapz, but sum*delta_f is fine

	disp('Fourier transform tests passed')
end

