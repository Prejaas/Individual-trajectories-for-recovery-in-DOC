#include "mex.h"
#include <vector>
#include <iostream>

using namespace std;

void convert(double* valid,double* output,mwSize nentries,int output_cols);
int get_output_cols(double* data,mwSize nentries);
vector<bool> dec2bin(double num);
void dec2bin(double* num,int* output,int output_cols);

void convert(double* valid,double* output,mwSize nentries,int output_cols){
	int temp[output_cols];
		
	for(int i = 0;i<nentries;++i,++valid){
		dec2bin(valid,temp,output_cols);
		for(int i = 0;i<output_cols;++i,++output)
			*output = temp[i];
	}
}

void dec2bin(double* num,int* output,int output_cols){
	// Do dec2bin but put the output in an appropriately sized array
	int k = int(*num);
	int* ptr = output+output_cols-1;
	for(int i = 0; i<output_cols;++i,--ptr){
		if(k>1){
			*ptr = k%2;
			k = k/2;
		}
		else if(k==1){
			*ptr = 1;
			k = 0;
		}
		else {
			*ptr = 0;
		}
	}
}


vector<bool> dec2bin(double num){
	vector<bool> out;
	int k = int(num);
	while(k > 1){
		out.push_back(k%2);
		k = k/2;
	}
	out.push_back(k);
	return out;
}

int get_output_cols(double* data, mwSize nentries){
	// First need to get the maximum entry
	double max_val = 0;
	vector<bool> x;
	for(int i = 0;i<nentries;++i,++data){
		if(*data > max_val)
			max_val=*data;
	}
	// Now work out how many digits are required to store it
	x = dec2bin(max_val);
	return x.size();
}

void transpose(double* in,double* out, mwSize nrows, int ncols){
	for(int i = 0; i<nrows;++i){
		for(int j = 0; j<ncols;++j){
			out[j*nrows+i] = int(in[i*ncols+j]);
		}
	}
}

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
	double *output;
	mxArray* transposed; // This is the output array
	double *valid; // Store the input
	int output_cols;
	mwSize mrows,ncols,nentries;

	if(nrhs!=1) 
		mexErrMsgTxt("One input required.");
	if(nlhs!=1) 
		mexErrMsgTxt("One output required.");

	// Calling syntax
	// x=mex_dec2bin(specvalid_final)

	valid = mxGetPr(prhs[0]);

	mrows = mxGetM(prhs[0]);
	ncols = mxGetN(prhs[0]);
	if(mrows>ncols)
		nentries = mrows;
	else
		nentries = ncols;
	
	output_cols = get_output_cols(valid,nentries);
	
	// Create the output array
	transposed = mxCreateDoubleMatrix(output_cols, nentries, mxREAL);

	plhs[0] = mxCreateDoubleMatrix(nentries, output_cols, mxREAL);
	output = mxGetPr(plhs[0]);
	
	convert(valid,mxGetPr(transposed),nentries,output_cols);
	transpose(mxGetPr(transposed),output,nentries,output_cols);
	mxDestroyArray(transposed);
 }
 
