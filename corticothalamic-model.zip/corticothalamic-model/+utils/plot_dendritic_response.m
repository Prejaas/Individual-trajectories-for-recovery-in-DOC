function plot_dendritic_response(alpha,beta)
	% This function plots the smoothed synaptic response for a given alpha and beta
	% The stimulus is a 1ms spike

	t_end = 2; % s
	t = [0 0.1 0.1+eps 0.101 0.101+eps t_end];
	stim = [0 0 1 1 0 0];

	[t_v,V] = rgk4(@(t,v) dendritic_de(t,v,alpha,beta),[0 t_end],[0 0]);
	plot(t,stim)
	hold on
	plot(t_v,V(:,2)./max(V(:,2)))
    
    % Add labels and limits
    xlabel('time [s]')
    ylabel('L_{ab}')
    title('Dendritic response function')
    xlim([t(1) t(end)/5])
    ylim([0 1.05])

function dvdt = dendritic_de(t,v,alpha,beta)
	% Post-synaptic response is in the second column 
	dvdt = zeros(2,1);

	if t > 0.1 && t < 0.101
		stim = 1;
	else
		stim = 0;
	end

	c1 = 1/alpha/beta;
	c2 = (1/alpha)+(1/beta);

	dvdt(1) = (stim - v(2) - c2*v(1))/c1;
	dvdt(2) = v(1);


function  [t,w] = rgk4(F,endpoints,alpha)
	% By Marc 03/01/03
	ts = 0.001;
	a = endpoints(1);
	b = endpoints(2);
	Steps = (b-a)/ts;
	n=length(alpha);

	t(1:(Steps+1)) = 0.0;     % initialize the variables

	w = zeros(Steps+1,n);

	h    = (b-a)/Steps;       % initialize the step size
	t(1) = a;                 % timestepping starts at time t=a
	w(1,:) = alpha;           % initial condition

	for k=1:Steps
	    t(k+1) = t(k) + h;                     % increment time
	    k1     = feval(F, t(k)    , w(k,:) )';         
	    k2     = feval(F, t(k)+h/2, w(k,:)+ h/2*k1 )';
	    k3     = feval(F, t(k)+h/2, w(k,:)+ h/2*k2 )';
	    k4     = feval(F, t(k)+h  , w(k,:)+ h*k3 )';
	    w(k+1,:) = w(k,:) + h/6*( k1 + 2*k2 + 2*k3 + k4 ); % Runge-Kutta method of order 2
	end
	t = t';
