#include "mex.h"

/*
 * mex_trapz.c - example found in API guide
 *
 * a stripped down clone of trapz.m that gives virtually the same output
 * but a fair bit faster
 * This function takes trapz over the columns
 * i.e. trapz(x,y) has x being (nx1) and y being (n x m)
 */

/* $Revision: 1.10.6.2 $ */

void trapz(double *x, double *y, double *z, mwSize rows, mwSize cols)
{
  mwSize row_index,col_index;

  double *x_ptr,*y_ptr;

  for(col_index=0;col_index<cols;++col_index){
    x_ptr = x;
    y_ptr = y+rows*col_index;
    for (row_index=0; row_index<rows-1; ++row_index,++x_ptr,++y_ptr){
        *(z+col_index) += (*(x_ptr+1)-*x_ptr)*(*(y_ptr+1)+*(y_ptr))/2;
    }
  }

  
}

/* the gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *x,*y,*z;
  mwSize x_mrows,x_ncols,nentries,y_mrows,y_ncols;
  
  /*  check for proper number of arguments */
  /* NOTE: You do not need an else statement when using mexErrMsgTxt
     within an if statement, because it will never get to the else
     statement if mexErrMsgTxt is executed. (mexErrMsgTxt breaks you out of
     the MEX-file) */
  if(nrhs!=2) 
    mexErrMsgTxt("Two inputs required.");
  if(nlhs>1) 
    mexErrMsgTxt("One output required.");
  
  /*  get the scalar input x */
  x = mxGetPr(prhs[0]);
  y = mxGetPr(prhs[1]);
  
  /* check dimensions of x */
  x_mrows = mxGetM(prhs[0]);
  x_ncols = mxGetN(prhs[0]);
  if( !(x_mrows==1 || x_ncols == 1))
    mexErrMsgTxt("The first argument must be a vector");
  nentries = x_mrows*x_ncols;

  /*  get the dimensions of the matrix input y */
  y_mrows = mxGetM(prhs[1]);
  y_ncols = mxGetN(prhs[1]);
  if( !(y_mrows==1 || y_ncols == 1) && y_mrows!=nentries)
    mexErrMsgTxt("In matrix mode, require column vectors and column orientation");

  if(y_mrows==1 || y_ncols == 1)
    y_ncols = 1;

  /*  set the output pointer to the output matrix */
  plhs[0] = mxCreateDoubleMatrix(1,y_ncols, mxREAL);
  
  /*  create a C pointer to a copy of the output matrix */
  z = mxGetPr(plhs[0]);
  
  /*  call the C subroutine */
  trapz(x,y,z,nentries,y_ncols);
  
}

