function [Vcount,V] = simple_bin3d(xyz,xyzlim,gridres,colour_parameter)
	% This is a stripped-down version of bin_3d that just bins the points
	% that are present
    xlim = (xyz(:,1) < xyzlim(2,1) & xyz(:,1) > xyzlim(1,1));
    ylim = (xyz(:,2) < xyzlim(2,2) & xyz(:,2) > xyzlim(1,2));
    zlim = (xyz(:,3) < xyzlim(2,3) & xyz(:,3) > xyzlim(1,3));

    xyz = xyz(xlim & ylim & zlim,:); 

    % There used to be some other code to get (xyz)BinIndex, but it hasn't 
    % been used for a while, so I have removed it
    xBinIndex = floor((xyz(:,1)-xyzlim(1,1))./gridres)+1;
    yBinIndex = floor((xyz(:,2)-xyzlim(1,2))./gridres)+1;
    zBinIndex = floor((xyz(:,3)-xyzlim(1,3))./gridres)+1;

    Vcount = zeros((xyzlim(2,2)-xyzlim(1,2))/gridres,(xyzlim(2,1)-xyzlim(1,1))/gridres,(xyzlim(2,3)-xyzlim(1,3))/gridres);

    if nargin == 4
        V = Vcount;
        colour_parameter = colour_parameter(xlim & ylim & zlim);
    end


    for zval = 1:max(zBinIndex)
	    this_z = zBinIndex==zval;
	
	    xb = xBinIndex(this_z);
	    yb = yBinIndex(this_z);

        if nargin == 4
            colour_z = colour_parameter(this_z);
        end

	    for j = 1:length(xb)-1
            if nargin == 4
                if ~isfinite(colour_z(j))
                    V(yb(j),xb(j),zval) =  V(yb(j),xb(j),zval) * Vcount(yb(j),xb(j),zval) / ( Vcount(yb(j),xb(j),zval)+1 );
                else
                    V(yb(j),xb(j),zval) =  V(yb(j),xb(j),zval) + colour_z(j); 
                end
            end
		    Vcount(yb(j),xb(j),zval) =  Vcount(yb(j),xb(j),zval)+1;
	    end
    end

    if nargin == 4
        V = V./Vcount; % Enable with finding mean properties
    end
