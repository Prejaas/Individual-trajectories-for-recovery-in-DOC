function draw_head(r,R,c)
	% Creates a annulus patch object and returns the handle.  Input arguments 
	% are the inner radius, outer radius, inner x offset, outer x offset, inner
	% y offset and outer Y offset.  Changes to the edgecolor and linestyle are
	% allowed, and will preserve the correct look of the annulus
	% From http://www.mathworks.com/matlabcentral/answers/3540-ring-annulis-patch 
	if nargin < 3 
		c = [0 0];
	end

	t = linspace(0,2*pi,200);
	x = c(1)+r*cos(t);
	y = c(2)+r*sin(t);
	X = c(1)+R*cos(t);
	Y = c(2)+R*sin(t);
	P = patch([x X],[y Y],[1 1 1],'linestyle','none','HitTest','off','FaceAlpha',0);
	L(1) = line(x,y,'color','k');

	% Draw the nose
	nose_width = 0.1; % Radians
	nose_distance = 0.015;
	t = [pi/2-nose_width, pi/2, pi/2+nose_width];
	plot(c(1)+r*cos(t),c(2) -(r*sin(t)+[0 nose_distance 0]),'k','HitTest','off');

	% And get a semicircle
	ear_radius = 0.015;
	t = linspace(pi/2,3*pi/2,20);
	x = ear_radius*cos(t);
	y = ear_radius*sin(t);
	plot(c(1)+x-r,c(2)+y,'k','HitTest','off')
	plot(c(1)-x+r,c(2)+y,'k','HitTest','off')
end
