function prw_imager(x,y,f,P,f_secondary,P_secondary,draw_head)
	% Visualize the power spectrum as a function of X, Y and frequency
	% Two panels - left panel is X and Y
	% Right panel is f and P

	% Provide P_analytic in case
	% Use 
	%{
	load spindle_points
	[f,P,grid_x,grid_y,Prw] = harness(wake_latest);
	analysis.prw_imager(grid_x,grid_y,f,Prw)
	%}
	if nargin < 7 || isempty(draw_head)
		if min(x(:))==0 % Try and guess if we are looking at space rather than spatial frequency
			draw_head = true; % If so, then draw a head for comparison
		else
			draw_head = false;
		end
	end

	if nargin < 5 || isempty(f_secondary)
		f_secondary = [];
		P_secondary = [];
		plot_secondary = false;
	else
		plot_secondary = true;
	end
	subplot(1,2,1);
	ax_1 = gca;
	cdata = squeeze(P(:,:,1));
	img = imagesc(x(1,:),y(:,1),cdata);

	colorbar
	ax_1.CLim = [min(cdata(:)) max(cdata(:))*1.1];
	hold on
	xb = ax_1.XBaseline;
	yb = ax_1.YBaseline;
	xb.BaseValue = 1;
	yb.BaseValue = 1;
	xb.Color = 'r';
	yb.Color = 'r';
	xb.Visible = 'on';
	yb.Visible = 'on';
	img.HitTest = 'off';
	title('Spatial power distribution')
	xlabel('X (m)');
	ylabel('Y (m)');

	if draw_head
		utils.draw_head(0.1995,0.1995,[0.25 0.25]);
		axis equal
		set(gca,'XLim',[0 0.5],'YLim',[0 0.5]);
	else
		set(gca,'XLim',[min(x(:)) max(x(:))],'YLim',[min(y(:)) max(y(:))]); % K-spectrum uses actual limits
	end

	subplot(1,2,2);
	ax_2 = gca;
	spec = loglog(f,squeeze(P(1,1,:)));
	spec.HitTest = 'off';
	ax_2.XLim = [1 45];
	ax_2.YLim = [min(P(:)) max(P(:))];
	fb = ax_2.XBaseline;
	fb.Color = 'r';
	fb.BaseValue = 0;
	fb.Visible = 'on';
	title('Power spectrum')
	xlabel('Frequency (Hz)')
	ylabel('Power spectral density')

	if plot_secondary
		hold on
		spec_secondary = loglog(f_secondary,squeeze(P_secondary(1,1,:)),'r--');
		spec_secondary.HitTest = 'off';
	end


	function update_spec(b)
		click_value = b.IntersectionPoint(1:2);
		[~,idx(1)] = min(abs(x(1,:)-click_value(1))); % This is the column (x value)
		[~,idx(2)] = min(abs(y(:,1)-click_value(2))); % This is the row (y value)

		spec.YData = squeeze(P(idx(2),idx(1),:)); % ... so they are reversed here into (row,col) = (y,x)
		if plot_secondary
			spec_secondary.YData = squeeze(P_secondary(idx(2),idx(1),:));
		end
		xb.BaseValue = click_value(1);
		yb.BaseValue = click_value(2);
	end

	function update_map(b)
		f_click = b.IntersectionPoint(1);
		[~,f_idx] = min(abs(f-f_click));
		fb.BaseValue = f(f_idx);
		cdata = squeeze(P(:,:,f_idx));
		img.CData = cdata;
		ax_1.CLim = [min(cdata(:)) max(cdata(:))+eps];
	end

	set(ax_1,'ButtonDownFcn', @(a,b)  update_spec(b) )
	set(ax_2,'ButtonDownFcn', @(a,b)  update_map(b) )

end