function output_fname = pfig(fname,imgformat,fhandle,path_prefix)
    % Saves an image file using 'print'
    %
    % This is useful to quickly save things inside a loop. It provides more
    % control than saveas() because it allows the resolution in dpi to be set.
    % 300dpi is sufficient for a high resolution tiff for inclusion in papers
    %
    % Usage:
    %	pfig('test') - save current figure as 'test.eps' to the desktop
    %   pfig('test',<type>) - Type are tiff, png, jpg
    %   pfig('test',<type>,<handle>)

    % First, set the figure to have the same output dimension in the file
    % as it does on the screen
    ppm_original = get(gcf,'PaperPositionMode');
    set(gcf,'PaperPositionMode','auto');
    orig_renderer = get(gcf,'Renderer');

	if nargin < 1
		error('Must provide a filename')
	end

	if nargin < 4 || isempty(path_prefix)
		if isunix()
			path_prefix = '~/Desktop';
		else
			path_prefix = 'C:/Users/romesh/Desktop';
		end
	end
	
	% If the image format is not specified
	if nargin < 2 || isempty(imgformat)
		% Try and get it from the filename
		if strfind(fname,'.')
			parts = regexp(fname,'\.','split');
			fname = parts{1};
			imgformat = parts{2};
		else
			% Otherwise, decide based on the figure renderer
			if strcmp(get(gcf,'Renderer'),'OpenGL')
				imgformat = 'png';
			else
				imgformat = 'eps';
			end
		end
	end
	
	% Use the current figure if no figure is specified
	if nargin < 3
	    fhandle = gcf;
	end

	switch imgformat
		case 'svg'
			plot2svg(sprintf('%s/%s.svg',path_prefix,fname),fhandle);
		case 'eps'
			if strcmp(get(gcf,'Renderer'),'opengl')
				set(gcf,'Renderer','painters')
			end
			print(fhandle,'-r300','-depsc',sprintf('%s/%s.eps',path_prefix,fname))
		case {'jpg','jpeg'} 
			print(fhandle,'-r300','-djpeg',sprintf('%s/%s.jpg',path_prefix,fname))
		case {'tif','tiff'}
			print(fhandle,'-r600','-dtiff',sprintf('%s/%s.tiff',path_prefix,fname))
		case {'pdf'} 		
			print(fhandle,'-r300','-dpdf',sprintf('%s/%s.pdf',path_prefix,fname))
		case {'png'} 
			print(fhandle,'-r600','-dpng',sprintf('%s/%s.png',path_prefix,fname))
		otherwise
			error(sprintf('Unknown format: %s',imgformat))
	end

	output_fname = sprintf('%s.%s',fname,imgformat);
	fprintf(1,'Image saved to %s/%s\n',path_prefix,output_fname)
	
	set(gcf,'PaperPositionMode',ppm_original);
	set(gcf,'Renderer',orig_renderer);