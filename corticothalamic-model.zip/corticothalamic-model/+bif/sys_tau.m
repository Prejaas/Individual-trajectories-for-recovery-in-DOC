function tau=sys_tau()

% xx:  phie phie1 ve ve1 vs vs1 vr vr1
% par: thetaonsigma abcprod abcsum nuee nuei nues nuse nusr nusn nure nurs tau0

tau=[12];

return;
