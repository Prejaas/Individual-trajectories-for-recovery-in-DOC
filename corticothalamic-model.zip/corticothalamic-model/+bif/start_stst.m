function stst=start_stst(parset)
% set up initial steady state


stst.kind='stst';

% xx:  phie phie1 ve ve1 vse vse1 vsr vsr1 vr vr1 Xtilde Htilde
% par: 1 thetaonsigma 2 abcprod 3 abcsum 4 nuee 5 nuei 6 nues 7 nuse 8 nusr 9 nusn 10 nure 11 nurs 
% par: 12 abcprodsr 13 abcsumsr 14 xtime 15 htime 16 ax 17 gXbar 18 gHbar 19 Icmus 20 tau0

'Dont forget to make changes to start_stst_seizures!'

if parset==1  
% wake
    theta=0.01292;                      %theta=0.015
    sigma=0.0038;                       % alt could define sigma, but matlab code uses sig0
    qmax=340;                           %qmax=250
    re=0.086;                           %re=0.08
    gammae=116;                         %gammae=100
    alpha=83.333333;                           %alpha=40
    beta=769.230769;                           %beta=4*alpha
    t0=0.085;                           %t0=0.08
    nuee=30.25e-4;                      %nuee=12e-4
    nuei=-60.01e-4;                     %nuei=-18e-4
    nues=20.55e-4;                       %nues=14e-4
    nuse=21.82e-4;                       %nuse=10e-4 couple 9
    nusr=-8.26e-4;                       %nusr=-10e-4 couple 10
    nusn=9.79e-4;                        % nusn=10e-4  % ==nusn*phin ?? So big??? 383.02e-4
    nure=3.27e-4;                       %nure=2e-4 couple 7
    nurs=0.32e-4;                        %nurs=2e-4 couple 8
    
    taux=0.15;
    tauh=0.60;
    alphar=83.333333;
    betar=769.230769;
    mu=16;                              %A/V m^-2
    qmaxr=100;
    Veff=-0.066;
    Vk=-0.095;
    Vx=0.14;
    gX=3;
    burstk=2.368;
    gH=burstk*gX;                     %- gX/3*(Veff-Vx)/(Veff-Vk);
    ax=0.003;
    Ic=0.123;                                % thetar*mu;
    Ib=-gX*(Veff-Vx)/3;
    Ia=Ib-gH*(Veff-Vk);
    X_ic= 0.0511;
    H_ic=  0.1534;
end    
    
if parset==2  
    % spindle
    theta=0.01292;                      %theta=0.015
    sigma=0.0038;                       % alt could define sigma, but matlab code uses sig0
    qmax=340;                           %qmax=250
    re=0.086;                           %re=0.08
    gammae=116;                         %gammae=100
    alpha=45;                           %alpha=40
    beta=185;                           %beta=4*alpha
    t0=0.085;                           %t0=0.08
    nuee=30.62e-4;                      %nuee=12e-4
    nuei=-32.41e-4;                     %nuei=-18e-4
    nues=9.21e-4;                       %nues=14e-4
    nuse=47.26e-4;                      %nuse=10e-4 couple 9
    nusr=-19.50e-4;                     %nusr=-10e-4 couple 10
    nusn=26.99e-4;                      % nusn=10e-4  % ==nusn*phin ?? So big??? 383.02e-4
    nure=2.6e-4;                       %nure=2e-4 couple 7
    nurs=28.76e-4;                        %nurs=2e-4 couple 8
    
    taux=0.15;
    tauh=0.60;
    alphar=45;
    betar= 185;
    mu=16;                              %A/V m^-2
    qmaxr=100;
    Veff=-0.066;
    Vk=-0.095;
    Vx=0.14;
    gX=3;
    burstk=2.368;
    gH=burstk*gX;                     %- gX/3*(Veff-Vx)/(Veff-Vk);
    ax=0.003;
    Ic=0.123;                                % thetar*mu;
    Ib=-gX*(Veff-Vx)/3;
    Ia=Ib-gH*(Veff-Vk);
    X_ic= 0.0851;
    H_ic=  0.2554;
end

if parset==3  
% deep sleep
    theta=0.01292;                      %theta=0.015
    sigma=0.0038;                       % alt could define sigma, but matlab code uses sig0
    qmax=340;                           %qmax=250
    re=0.086;                           %re=0.08
    gammae=116;                         %gammae=100
    alpha=45;                           %alpha=40
    beta=185;                           %beta=4*alpha
    t0=0.085;                           %t0=0.08
    nuee=48.28e-4;                      %nuee=12e-4
    nuei=-49.15e-4;                     %nuei=-18e-4
    nues=7.81e-4;                       %nues=14e-4
    nuse=20.12e-4;                      %nuse=10e-4 couple 9
    nusr=-32.26e-4;                     %nusr=-10e-4 couple 10
    nusn=383.02e-4;%0*68.4e-4;          % nusn=10e-4  % ==nusn*phin ?? So big??? 383.02e-4
    nure=2.65e-4;                       %nure=2e-4 couple 7
    nurs=0.2e-4;                        %nurs=2e-4 couple 8
    
    taux=0.15;
    tauh=0.60;
    alphar=45;
    betar= 185;
    mu=16;                              %A/V m^-2
    qmaxr=100;
    Veff=-0.066;
    Vk=-0.095;
    Vx=0.14;
    gX=3;
    burstk=2.368;
    gH=burstk*gX;                     %- gX/3*(Veff-Vx)/(Veff-Vk);
    ax=0.003;
    Ic=0.123;                                % thetar*mu;
    Ib=-gX*(Veff-Vx)/3;
    Ia=Ib-gH*(Veff-Vk);
    X_ic= 0.064154707899651;
    H_ic=  0.192464123698954;
end    

if parset==4  
    % seizure
    theta=0.015;                        %theta=0.015
    sig0=0.006; sigma=sig0*sqrt(3)/pi;  %sig0=0.006  % alt could define sigma, but matlab code uses sig0
    qmax=250;                           %qmax=250
    re=0.08;                            %re=0.08
    gammae=100;                         %gammae=100
    alpha=50;                           %alpha=60
    beta=4*alpha;                       %beta=4*alpha
    t0=0.08;                            %t0=0.08
    nuee=10e-4;                       %nuee=12e-4
    nuei=-18e-4;                        %nuei=-18e-4
    nues=32e-4;                       %nues=14e-4 Couple 3
    nuse=17e-4;                       %nuse=10e-4 Couple 9
    nusr=-8e-4;                      %nusr=-10e-4 Couple 10
    nusn=20e-4;                         %12e-4 in James' original pt;
    nure=16e-4;                        %nure=2e-4 Couple 7
    nurs=6e-4;                        %nurs=2e-4 Couple 8
    
    taux=0.15;
    tauh=0.60;
    alphar=alpha;
    betar= 4*alphar;
    mu=16;                              %A/V m^-2
    qmaxr=80;
    Veff=-0.066;
    Vk=-0.095;
    Vx=0.14;
    gX=3;
    burstk=2.368;
    gH=gX*burstk;	                     %- gX/3*(Veff-Vx)/(Veff-Vk);    gX*2.368;  
    ax=0.003;
    Ic=0.176;                                % thetar*mu;
    Ib=-gX*(Veff-Vx)/3;
    Ia=Ib-gH*(Veff-Vk);
    X_ic=0.0402;
    H_ic=0.1205;
end    


%% calculate initial conditions
r=0.000;%0.002;%*(rand-0.5); % perturb ICs from fixed pt
ve_ic=fzero(@ve_root,-3e-3)+r; % NB: needs to be much closer to actual soln else saturates to Qmax!!!
% fzero finds zero near function near X0.
% single var nonlinear zero-finder X = FZERO(FUN,X0) find zero of FUN near
% X0. FUN is function handle

phie_ic=s(ve_ic);
vr_ic=nure*phie_ic+(nurs/nues)*(ve_ic-(nuee+nuei)*phie_ic); % eqn 28 sub in 27
phir_ic=s(vr_ic);
vs_ic=nuse*phie_ic+nusr*phir_ic+nusn; % eqn 29


% thetar=(Ic-3*Ib*X_ic+(Ib-Ia)*3*X_ic)/mu;
% X_ic=ax*qmaxr/(1+exp(-(vr_ic-thetar)/sigma));

% rescalings
% abcprod = alpha beta/gammae^2, 
% abcsum = (1/alpha + 1/beta) gammae,
% abcprodsr = alphasr betasr/gammae^2, 
% abcsumsr = (1/alphasr + 1/betasr) gammae, 
% xtimes = 1/(taux*gammae) htimes = 1/(tauh*gammae) 
% axbar = ax * qmaxr;
% gHbar = gH (Veff - Vk)/(mu*sigma), gXbar = gX (Veff - Vx)/(mu*sigma)
% Iamus = Ia/(mu*sigma)
kt=1/gammae;    % t = 1/gammae * tau
kv=sigma;       % va = sigma vabar             sigma V
kps=qmax;       % phie = qmax phiebar

% setup stst: params, x = dimensions of system 
stst.parameter=[theta/kv,alpha*beta*kt^2,(1/alpha+1/beta)/kt,nuee*kps/kv,nuei*kps/kv,nues*kps/kv,nuse*kps/kv,nusr*kps/kv,nusn*1/kv,nure*kps/kv,nurs*kps/kv,t0/2/kt];
%  par: thetaonsigma, abcprod, abcsum, nuee, nuei, nues, nuse, nusr, nusn, nure, nurs, t0

stst.x=[phie_ic/kps 0 ve_ic/kv 0 vs_ic/kv 0 vr_ic/kv 0]'; 
% xx:    phie     phie1 ve    ve1 vse    vse1 vsr     vsr1 vr     vr1 Xtilde Htilde
% xx:  phie   phie1 ve ve1 vs vs1 vr vr1

method=df_mthod('stst'); % returns struct
[stst,success]=p_correc(stst,[],[],method.point); % in case ic not close enuf for biftool; return stst struct
if ~success,
    fprintf(1,'correction failed\n')
end
method.stability.minimal_real_part=-2; % default -1/tau more -ve value gives more roots (infinite)
stst.stability=p_stabil(stst,method.stability);

figure
p_splot(stst)

function out=s(v)
% sigmoid function
% uses theta, sig, and qmax from above
    out=qmax./(1+exp((theta-v)/sigma)); 
end


function out=ve_root(ve)
    out=s(nuse*s(ve)+nusr*s(nure*s(ve)+(nurs/nues)*(ve-(nuee+nuei)*s(ve)))+nusn)     +((nuee+nuei)*s(ve)-ve)/nues;
end
keyboard
end