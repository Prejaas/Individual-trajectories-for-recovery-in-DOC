function f=sys_rhs(xx, par)

% xx:  phie phie1 ve ve1 vs vs1 vr vr1
% par: thetaonsigma abcprod abcsum nuee nuei nues nuse nusr nusn nure nurs tau0
e=exp(1);
f(1,1)=xx(2,1);
f(2,1)=1/(1 + e^(par(1) - xx(3,1))) - xx(1,1) - 2*xx(2,1);
f(3,1)=xx(4,1);
f(4,1)=par(2)*(par(5)/(1 + e^(par(1) - xx(3,1))) + par(6)/(1 + e^(par(1) - xx(5,2))) + par(4)*xx(1,1) - xx(3,1) - par(3)*xx(4,1));
f(5,1)=xx(6,1);
f(6,1)=par(2)*(par(8)/(1 + e^(par(1) - xx(7,1))) + par(9) + par(7)*xx(1,2) - xx(5,1) - par(3)*xx(6,1));
f(7,1)=xx(8,1);
f(8,1)=par(2)*(par(11)/(1 + e^(par(1) - xx(5,1))) + par(10)*xx(1,2) - xx(7,1) - par(3)*xx(8,1));

return;
