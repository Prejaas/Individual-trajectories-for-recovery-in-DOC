function stab =isstab(p)
    % set up initial steady state
    import bif.df_mthod
    import model.mex_ve_root
    import model.sigm
    
    if length(p.ve) > 1
        error('Must have a single root to check');
    end

    stst.kind='stst';

    %% calculate initial conditions
    % Note that phin(0,0) = 1 IS ASSUMED
    ve_ic=fzero(@(v) mex_ve_root(v,p.nus,p.theta,p.sigma,p.qmax),p.ve);
    phie_ic=sigm(ve_ic,p);
    vr_ic=p.nus(7)*phie_ic+(p.nus(8)/p.nus(3))*(ve_ic-(p.nus(1)+p.nus(2))*phie_ic); % eqn 28 sub in 27
    phir_ic=sigm(vr_ic,p);
    vs_ic=p.nus(4)*phie_ic+p.nus(5)*phir_ic+p.nus(6); % eqn 29

    kt=1/p.gammae;    % t = 1/gammae * tau
    kv=p.sigma;       % va = sigma vabar             sigma V
    kps=p.qmax;       % phie = qmax phiebar

    % RESCALED PARAMETERS: par: thetaonsigma, abcprod, abcsum, nuee, nuei, nues, nuse, nusr, nusn, nure, nurs, t0
    stst.parameter=[p.theta/kv,p.alpha(1)*p.beta(1)*kt^2,(1/p.alpha(1)+1/p.beta(1))/kt,p.nus(1)*kps/kv,p.nus(2)*kps/kv,p.nus(3)*kps/kv,p.nus(4)*kps/kv,p.nus(5)*kps/kv,p.nus(6)*1/kv,p.nus(7)*kps/kv,p.nus(8)*kps/kv,p.t0/2/kt];

    % VARIABLES: xx:  phie   phie1 ve ve1 vs vs1 vr vr1
    stst.x=[phie_ic/kps 0 ve_ic/kv 0 vs_ic/kv 0 vr_ic/kv 0]'; 
    
    method=df_mthod('stst'); % returns struct
    [stst,success]=p_correc(stst,[],[],method.point); % in case ic not close enuf for biftool; return stst struct
    if ~success,
        fprintf(1,'correction failed\n')
    end
    method.stability.minimal_real_part=-2; % default -1/tau more -ve value gives more roots (infinite)
    stst.stability=p_stabil(stst,method.stability);

    %figure
    %p_splot(stst)

    stab = real(stst.stability.l1(1))<0;
