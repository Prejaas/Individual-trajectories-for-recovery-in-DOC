function mat=sys_deri(xx, par, nx, np, v)

% xx:  phie phie1 ve ve1 vs vs1 vr vr1
% par: thetaonsigma abcprod abcsum nuee nuei nues nuse nusr nusn nure nurs tau0

mat=[];
e=exp(1);
if length(nx)==1 && isempty(np) && isempty(v)
	if nx==0
		mat(2,1)=-1;
		mat(4,1)=par(2)*par(4);
		mat(1,2)=1;
		mat(2,2)=-2;
		mat(2,3)=e^(par(1) + xx(3,1))/(e^par(1) + e^xx(3,1))^2;
		mat(4,3)=par(2)*(-1 + (e^(par(1) + xx(3,1))*par(5))/(e^par(1) + e^xx(3,1))^2);
		mat(3,4)=1;
		mat(4,4)=-(par(2)*par(3));
		mat(6,5)=-par(2);
		mat(8,5)=(e^(par(1) + xx(5,1))*par(2)*par(11))/(e^par(1) + e^xx(5,1))^2;
		mat(5,6)=1;
		mat(6,6)=-(par(2)*par(3));
		mat(6,7)=(e^(par(1) + xx(7,1))*par(2)*par(8))/(e^par(1) + e^xx(7,1))^2;
		mat(8,7)=-par(2);
		mat(7,8)=1;
		mat(8,8)=-(par(2)*par(3));
	elseif nx==1
		mat(6,1)=par(2)*par(7);
		mat(8,1)=par(2)*par(10);
		mat(4,5)=(e^(par(1) + xx(5,2))*par(2)*par(6))/(e^par(1) + e^xx(5,2))^2;
		mat(8,8)=0;
	end;
elseif isempty(nx) && length(np)==1 && isempty(v)
	if np==1
		mat(2,1)=-(e^(par(1) + xx(3,1))/(e^par(1) + e^xx(3,1))^2);
		mat(4,1)=par(2)*(-((e^(par(1) + xx(3,1))*par(5))/(e^par(1) + e^xx(3,1))^2) - (e^(par(1) + xx(5,2))*par(6))/(e^par(1) + e^xx(5,2))^2);
		mat(6,1)=-((e^(par(1) + xx(7,1))*par(2)*par(8))/(e^par(1) + e^xx(7,1))^2);
		mat(8,1)=-((e^(par(1) + xx(5,1))*par(2)*par(11))/(e^par(1) + e^xx(5,1))^2);
	elseif np==2
		mat(4,1)=par(5)/(1 + e^(par(1) - xx(3,1))) + par(6)/(1 + e^(par(1) - xx(5,2))) + par(4)*xx(1,1) - xx(3,1) - par(3)*xx(4,1);
		mat(6,1)=par(8)/(1 + e^(par(1) - xx(7,1))) + par(9) + par(7)*xx(1,2) - xx(5,1) - par(3)*xx(6,1);
		mat(8,1)=par(11)/(1 + e^(par(1) - xx(5,1))) + par(10)*xx(1,2) - xx(7,1) - par(3)*xx(8,1);
	elseif np==3
		mat(4,1)=-(par(2)*xx(4,1));
		mat(6,1)=-(par(2)*xx(6,1));
		mat(8,1)=-(par(2)*xx(8,1));
	elseif np==4
		mat(4,1)=par(2)*xx(1,1);
		mat(8,1)=0;
	elseif np==5
		mat(4,1)=par(2)/(1 + e^(par(1) - xx(3,1)));
		mat(8,1)=0;
	elseif np==6
		mat(4,1)=par(2)/(1 + e^(par(1) - xx(5,2)));
		mat(8,1)=0;
	elseif np==7
		mat(6,1)=par(2)*xx(1,2);
		mat(8,1)=0;
	elseif np==8
		mat(6,1)=par(2)/(1 + e^(par(1) - xx(7,1)));
		mat(8,1)=0;
	elseif np==9
		mat(6,1)=par(2);
		mat(8,1)=0;
	elseif np==10
		mat(8,1)=par(2)*xx(1,2);
	elseif np==11
		mat(8,1)=par(2)/(1 + e^(par(1) - xx(5,1)));
	elseif np==12
		mat(8,1)=0;
	end;
elseif length(nx)==1 && length(np)==1 && isempty(v)
	if nx==0
		if np==1
			mat(2,3)=(e^(par(1) + xx(3,1))*(-e^par(1) + e^xx(3,1)))/(e^par(1) + e^xx(3,1))^3;
			mat(4,3)=(e^(par(1) + xx(3,1))*(-e^par(1) + e^xx(3,1))*par(2)*par(5))/(e^par(1) + e^xx(3,1))^3;
			mat(8,5)=(e^(par(1) + xx(5,1))*(-e^par(1) + e^xx(5,1))*par(2)*par(11))/(e^par(1) + e^xx(5,1))^3;
			mat(6,7)=(e^(par(1) + xx(7,1))*(-e^par(1) + e^xx(7,1))*par(2)*par(8))/(e^par(1) + e^xx(7,1))^3;
			mat(8,8)=0;
		elseif np==2
			mat(4,1)=par(4);
			mat(4,3)=-1 + (e^(par(1) + xx(3,1))*par(5))/(e^par(1) + e^xx(3,1))^2;
			mat(4,4)=-par(3);
			mat(6,5)=-1;
			mat(8,5)=(e^(par(1) + xx(5,1))*par(11))/(e^par(1) + e^xx(5,1))^2;
			mat(6,6)=-par(3);
			mat(6,7)=(e^(par(1) + xx(7,1))*par(8))/(e^par(1) + e^xx(7,1))^2;
			mat(8,7)=-1;
			mat(8,8)=-par(3);
		elseif np==3
			mat(4,4)=-par(2);
			mat(6,6)=-par(2);
			mat(8,8)=-par(2);
		elseif np==4
			mat(4,1)=par(2);
			mat(8,8)=0;
		elseif np==5
			mat(4,3)=(e^(par(1) + xx(3,1))*par(2))/(e^par(1) + e^xx(3,1))^2;
			mat(8,8)=0;
		elseif np==6
			mat(8,8)=0;
		elseif np==7
			mat(8,8)=0;
		elseif np==8
			mat(6,7)=(e^(par(1) + xx(7,1))*par(2))/(e^par(1) + e^xx(7,1))^2;
			mat(8,8)=0;
		elseif np==9
			mat(8,8)=0;
		elseif np==10
			mat(8,8)=0;
		elseif np==11
			mat(8,5)=(e^(par(1) + xx(5,1))*par(2))/(e^par(1) + e^xx(5,1))^2;
			mat(8,8)=0;
		elseif np==12
			mat(8,8)=0;
		end;
	elseif nx==1
		if np==1
			mat(4,5)=(e^(par(1) + xx(5,2))*(-e^par(1) + e^xx(5,2))*par(2)*par(6))/(e^par(1) + e^xx(5,2))^3;
			mat(8,8)=0;
		elseif np==2
			mat(6,1)=par(7);
			mat(8,1)=par(10);
			mat(4,5)=(e^(par(1) + xx(5,2))*par(6))/(e^par(1) + e^xx(5,2))^2;
			mat(8,8)=0;
		elseif np==3
			mat(8,8)=0;
		elseif np==4
			mat(8,8)=0;
		elseif np==5
			mat(8,8)=0;
		elseif np==6
			mat(4,5)=(e^(par(1) + xx(5,2))*par(2))/(e^par(1) + e^xx(5,2))^2;
			mat(8,8)=0;
		elseif np==7
			mat(6,1)=par(2);
			mat(8,8)=0;
		elseif np==8
			mat(8,8)=0;
		elseif np==9
			mat(8,8)=0;
		elseif np==10
			mat(8,1)=par(2);
			mat(8,8)=0;
		elseif np==11
			mat(8,8)=0;
		elseif np==12
			mat(8,8)=0;
		end;
	end;
elseif length(nx)==2 && isempty(np) && ~isempty(v)
	if nx(1)==0
		if nx(2)==0
			mat(2,3)=-((e^(par(1) + xx(3,1))*(-e^par(1) + e^xx(3,1))*v(3))/(e^par(1) + e^xx(3,1))^3);
			mat(4,3)=-((e^(par(1) + xx(3,1))*(-e^par(1) + e^xx(3,1))*par(2)*par(5)*v(3))/(e^par(1) + e^xx(3,1))^3);
			mat(8,5)=-((e^(par(1) + xx(5,1))*(-e^par(1) + e^xx(5,1))*par(2)*par(11)*v(5))/(e^par(1) + e^xx(5,1))^3);
			mat(6,7)=-((e^(par(1) + xx(7,1))*(-e^par(1) + e^xx(7,1))*par(2)*par(8)*v(7))/(e^par(1) + e^xx(7,1))^3);
			mat(8,8)=0;
		elseif nx(2)==1
			mat(8,8)=0;
		end;
	elseif nx(1)==1
		if nx(2)==0
			mat(8,8)=0;
		elseif nx(2)==1
			mat(4,5)=-((e^(par(1) + xx(5,2))*(-e^par(1) + e^xx(5,2))*par(2)*par(6)*v(5))/(e^par(1) + e^xx(5,2))^3);
			mat(8,8)=0;
		end;
	end;
end;

if isempty(mat)
	err=[nx np size(v)];
	error('sys_deri: requested derivative could not be computed!');
end;

return;
