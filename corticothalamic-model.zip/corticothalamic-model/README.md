# Corticothalamic Model
This repository contains Matlab programs specific to the Robinson et. al. corticothalamic neural field model. The core components provided are

- A container object [`model.params`](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/Parameters-objects) that stores the model parameters and provides a range of useful functions for calculation of steady states, power spectra and evoked responses.
- Example parameter objects (including parameter values) for wake and sleep states (`example_parameters.mat`) _These are the parameters published in Abeysuriya, R. G., Rennie, C. J., & Robinson, P. A. (2015). Physiologically based arousal state estimation and dynamics. Journal of Neuroscience Methods_
- Example parameter objects for wake and spindle states (`spindle_parameters.mat`). _These are the parameters published in Abeysuriya, R. G., Rennie, C. J., & Robinson, P. A. (2014). Prediction and verification of nonlinear sleep spindle harmonic oscillations. Journal of Theoretical Biology_
- Example parameter objects corresponding to trajectories between wake and sleep where only three of the connection strengths are changed (`minimal_ec_to_n2.mat`). These trajectories show transitions from wake to sleep with minimal changes in parameter values.
- Code to calculate and draw the [reduced model stability boundary](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/Stability-boundary)
- An [interactive 'widget'](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/Interactive-widget) to explore the model's parameter space
- Utility functions for [`NFTsim`](https://github.com/BrainDynamicsUSYD/nftsim) to [write configuration files](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/NFTsim-helpers). You will need to install `NFTsim` in order to use these functions.
- [Various utility functions](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/Utilities) for Fourier transforms and printing figures
- Notes on how to derive the model equations (in the `derivation` folder)

### Setup instructions
To use this repository, add the `corticothalamic-model` folder to your Matlab path. You will also need to compile the included MEX files. Further instructions are provided [in the wiki](https://github.com/BrainDynamicsUSYD/corticothalamic-model/wiki/Setup).

