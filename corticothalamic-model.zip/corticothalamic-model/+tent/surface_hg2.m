function edgeplot = surface_hg2(xyzlim,draw_surface,boundary_type)
	% Use instead of surfaces.m to plot the surfaces
	% Run 'tent.surface_hg2' to see the output

	% boundary_type determines whether a1=0 or the h_theta boundary is plotted
	% options are 'h_theta','a1','both'

	if nargin < 3 || isempty(boundary_type)
		boundary_type = 'h_theta';
	end

	if nargin < 2 || isempty(draw_surface)
		draw_surface = true;
	end


	if nargin < 1 || isempty(xyzlim)
		% Limits for the normal tent blobs
		% xyzlim = [0   -0.25   0; ... % axis limits for the background grid
		%           1.25 1.0  0.9];

		% Limits for fit figure iso
		xyzlim = [0   -0.5   0; ... % axis limits for the background grid
		          1.25 1.0  1];

		% % % Limit for fit figure front
  %       xyzlim = [0   -0.25   0; ... % axis limits for the background grid
  %                 1.25 0.6 0.2];

  %       % % Limits for fit figure top
  %       xyzlim = [0.25   -0.25   0; ... % axis limits for the background grid
  %                 1      0.75  0.5];
  		gridres = 0.01;
    end


    hfig = gcf;
    ax = gca;
    hold(ax,'on')
    c = ax.Children;
    for j = 1:length(c)
    	if strcmp(c(j).UserData,'tent')
    		delete(c(j));
    	end
    end

    ax.View = [112 18];

    if draw_surface
	    [x,y,z,u] = tent.compute;

		tent_filter = x>=xyzlim(1,1) & x<=xyzlim(2,1) & y>=xyzlim(1,2) & y<=xyzlim(2,2);
		x(~tent_filter) = NaN;
		y(~tent_filter) = NaN;
		z(~tent_filter) = NaN;


		edgeplot = mesh(x,y,z);
		set(edgeplot,'EdgeColor','k','LineWidth',0.5,'FaceColor','none')
		edge_alphadata = x+y<0.90 & x > 0 & x < 1 & y > xyzlim(1,2);
		set(edgeplot,'AlphaData',+edge_alphadata,'EdgeAlpha','flat','AlphaDataMapping','none')
	else
		edgeplot = [];
	end


	drawnow

    ax.XLim = [xyzlim(1,1) xyzlim(2,1)];
    ax.YLim = [xyzlim(1,2) xyzlim(2,2)];
	ax.ZLim = [xyzlim(1,3) xyzlim(2,3)];
	
	ax.XTick = [xyzlim(1,1):gridres:xyzlim(2,1)];
	ax.YTick = [xyzlim(1,2):gridres:xyzlim(2,2)];
	ax.ZTick = [xyzlim(1,3)+gridres:gridres:xyzlim(2,3)];

	p = model.params;


	a0_lines=plot3([0 1+2/(p.gammae*p.t0)],[1 -2/(p.gammae*p.t0)],[0 0],'k--','LineWidth',2,'Parent',ax);
	
	if strcmp(boundary_type,'both') || strcmp(boundary_type,'a1')
		a1_lines=plot([0 1+2/(p.gammae*p.t0)],[-2/(p.gammae*p.t0) -2/(p.gammae*p.t0)],'k--','LineWidth',2,'Parent',ax);
	end

	if strcmp(boundary_type,'both') || strcmp(boundary_type,'h_theta')
		% Draw James's H_theta0 boundary from 2012 Corticothalamic Dynamics
		w = 2*pi*linspace(0,5,200);
		x = 1 - w.^2/p.gammae^2 + 2*w/p.gammae.*cot(w*p.t0);
		y = -2*w/p.gammae.*csc(w*p.t0);
		h_theta_lines = plot3(x,y,zeros(size(x)),'k--','LineWidth',2,'Parent',ax);
	end

	drawnow 

	zr = ax.ZRuler;
	
	zr.FirstCrossoverValue  = -Inf;
	zr.SecondCrossoverValue = Inf;

	yr = ax.YRuler;

	yr.FirstCrossoverValue = Inf;

	xb = ax.XBaseline;
	xb.BaseValue = 0;
	xb.Visible = 'on';
	yb = ax.YBaseline;
	yb.Visible = 'on';
	zb = ax.ZBaseline;
	zb.Visible = 'on';
	
	grid(ax,'on');
	hfig.Color = 'w';

