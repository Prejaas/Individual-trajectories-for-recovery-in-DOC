function surface(xyzlim)
	% This function formats tent plots
	% The idea is that you plot something in XYZ, then do 'hold on'
	% and run 'tent.surface' to apply formatting
	%
	% Note that this code is designed for Matlab R2014a or earlier
	% The figure produced is publication quality and neat, but is 
	% very difficult to do any further work with. If you can, use
	% tent.surface_hg2 which is designed for the new graphics engine
	% and is superior in pretty much every way. 

	% Remove any existing tents
	% Keep only the blobs
	c = get(gca,'Children');
	for j = 1:length(c)
		if strcmp(get(c(j),'UserData'),'tent')
			delete(c(j));
		end
	end

	if nargin < 1 || isempty(xyzlim)
		% Limits for the normal tent blobs
		% xyzlim = [0   -0.25   0; ... % axis limits for the background grid
		%           1.25 1.0  0.9];
		% plot_xyzlim = [0   -0.3   0; ... % Axis limits for the actual plot
		%         1.5 1.1  0.9];

		% Limits for fit figure iso
		xyzlim = [0   -0.25   0; ... % axis limits for the background grid
		          1.25 1.0  0.5];
		plot_xyzlim = [0   -0.3   0; ... % Axis limits for the actual plot
		        1.5 1.1  0.6];

		% % % Limit for fit figure front
  %       xyzlim = [0   -0.25   0; ... % axis limits for the background grid
  %                 1.25 0.6 0.2];
  %       plot_xyzlim = [0   -0.3   -0.05; ... % Axis limits for the actual plot
  %               1.5 0.65  0.22];

  %       % % Limits for fit figure top
  %       xyzlim = [0.25   -0.25   0; ... % axis limits for the background grid
  %                 1      0.75  0.5];
  %       plot_xyzlim = [0.22  -0.3   0; ... % Axis limits for the actual plot
  %               1.02 0.77  0.6];


    end

	% Put a white floor on the plot to get a clean intersection between the tent and Z=0
	%plot_floor = patch([0 xyzlim(2,1) xyzlim(2,1) 0],[xyzlim(1,2) xyzlim(1,2) xyzlim(2,2) xyzlim(2,2)],[0 0 0 0],'w')
	%set(plot_floor,'FaceColor','w','LineStyle','none')
	axis equal
	set(gca,'XLim',[plot_xyzlim(1,1) plot_xyzlim(2,1)],'YLim',[plot_xyzlim(1,2) plot_xyzlim(2,2)],'ZLim',[0 plot_xyzlim(2,3)])
	
    grid_res = 0.01;
	% DRAW GRIDLINES
	xv = [xyzlim(1,1) :grid_res:xyzlim(2,1)];
	yv = [xyzlim(1,2):grid_res:xyzlim(2,2)];
	zv = [xyzlim(1,3):grid_res:xyzlim(2,3)];
	set(gca,'XTick',xv,'YTick',yv,'XTickLabel',xv,'YTickLabel',yv,'ZTick',zv,'ZTickLabel',zv);

	xg = [];
	yg = [];
	for j = 2:length(xv)-1
		xg = [xg xv(j) xv(j) NaN];
		yg = [yg xyzlim(1,2) xyzlim(2,2) NaN];
	end

	for j = 2:length(yv)-1
		xg = [xg xyzlim(1,1) xyzlim(2,1) NaN];
		yg = [yg yv(j) yv(j) NaN];
	end
	gridlines = plot3(xg,yg,zeros(size(xg)),'-','Color',0.8*ones(1,3));
	p = model.params;

	% DRAW A0=0 and A1=0
	a0_lines=plot3([0 1+2/(p.gammae*p.t0) NaN 0 1+2/(p.gammae*p.t0)],[-2/(p.gammae*p.t0) -2/(p.gammae*p.t0) NaN 1 -2/(p.gammae*p.t0)],[0 0 NaN 0 0],'k--','LineWidth',2)

	% Draw axes
	axis_lines=plot3([0 xyzlim(2,1) NaN 0 0 NaN 0 0],[0 0 NaN xyzlim(1,2) xyzlim(2,2) NaN 0 0],[0 0 NaN 0 0 NaN 0 xyzlim(2,3)],'k','LineWidth',1)
	box_lines= plot3([xyzlim(1,1)  xyzlim(2,1) NaN xyzlim(1,1) xyzlim(2,1) NaN xyzlim(2,1) xyzlim(2,1) NaN xyzlim(1,1) xyzlim(1,1)],[xyzlim(1,2) xyzlim(1,2) NaN xyzlim(2,2) xyzlim(2,2) NaN xyzlim(1,2) xyzlim(2,2) NaN xyzlim(1,2) xyzlim(2,2)],[0 0 NaN 0 0 NaN 0 0 NaN 0 0],'k');
	set(axis_lines,'UserData','axis_lines');
	set(box_lines,'UserData','box_lines');

	% Now, the tentsurface
    % DISABLED TENT
% 	d = load('packages/+tent/tentsurface');
% 	x = d.x;
% 	y = d.y;
% 	z= d.z_max.mixed;
% 	tent_filter = x>=xyzlim(1,1) & x<=xyzlim(2,1) & y>=xyzlim(1,2) & y<=xyzlim(2,2);
% 	x(~tent_filter) = NaN;
% 	y(~tent_filter) = NaN;
% 	z(~tent_filter) = NaN;

	%H = fspecial('gaussian',[5 5],1)
	%zt = [z(:,1) z(:,1) z];
	%zt = filter2(H,zt);
	%z = zt(:,3:end);

	%edgeplot = mesh(x,y,z)
	%set(edgeplot,'EdgeColor','k','LineWidth',0.5,'FaceColor','none')
	
	%edge_alphadata = x+y<0.95 & x > 0.0;
	%set(edgeplot,'AlphaData',+edge_alphadata,'EdgeAlpha','flat','AlphaDataMapping','none')
	
	% DEBUG
	%delete(edgeplot);
% 
% 	tent_filter = x>=xyzlim(1,1) & x<=xyzlim(2,1) & y>=xyzlim(1,2) & y<=xyzlim(2,2) & x+y<0.95 & x > 0.0 & z >= 0;
% 	x(~tent_filter) = NaN;
% 	y(~tent_filter) = NaN;
% 	z(~tent_filter) = NaN;
% 	edgeplot = mesh(x,y,z)
% 	set(edgeplot,'EdgeColor','k','LineWidth',0.5,'FaceColor','none')

	% Compute the EDGE alpha data
	% [Nx,Ny,Nz] = surfnorm(x,y,z);
	% a = z > 0; % Things above zero
	%a =  ;
	%a = x+y<0.99;
	% a = a & (x+y < 1 | (x+y<=1 & x < 0.2));
	% a = a & ~(Nz < 0.4 & y > -0.2 );
	% %a(21:22,23) = 0;
	% a(25:26,19) = 0;
	% a(21:end,18:24) = 0;
	% a(22,19) = 1;
	% a(20,21) = 0;
	% a(20,22) = 0;
	% a(21,21) = 0;
	% a(20,21) = 0;
	%set(edgeplot,'AlphaData',+a,'EdgeAlpha','flat','AlphaDataMapping','none')

	% And now we do it again for the surface plot
	% The surface plot sets opaque faces for the scalloped region
% 	surfplot = surface(x,y,z)
% 	set(surfplot,'LineStyle','none','FaceColor','w')

	% Compute the SURFACE alpha data
% 	a = z > 0; % Things above zero
% 	a = a & (x+y < 0.75 | (x+y<=1 & x < 0.2));
% 	a = a & x < 0.8 & y < 0.2 & z > 0.4;
% 	a = ~isfinite(a);
% 	set(surfplot,'AlphaData',+a,'FaceAlpha','flat','AlphaDataMapping','none')

	axis off
	set(gcf,'Color','w')

	%set(edgeplot,'HitTest','off');
	%set(surfplot,'HitTest','off');

	% RECOLOR!

	% bands = [1 4;... % delta
	%  4 7.5; ... % theta
	%  7.5 13; ... % alpha
	%  11 16; ... % sigma (overlaps alpha and beta)
	%  13 30; ...  % beta
	%  30 45; ... % gamma
	%  ];

	% colors = [;...
	% 1 0 0;...
	% 1 0 0;...
	% 0 0.7 0;...
	% 0 0 1;...
	% 0 0 1;...
	% 0 0 1;...
	% ];

	% set(gcf,'Colormap',colors);
	% set(gca,'CLim',[1 size(colors,1)]);

	% b = d.f_max.mixed
	% b(~isfinite(b)) = 0;
	% for j = 1:size(bands,1)
	% 	b(b>bands(j,1) & b <= bands(j,2)) = j;
	% end
	% set(edgeplot,'CData',b,'EdgeColor','flat')
	% %set(edgeplot,'EdgeColor','interp')
	
	set(gca,'View',[   112    18]);


% 	set(edgeplot,'Visible','off');
% 	set(surfplot,'Visible','off');
