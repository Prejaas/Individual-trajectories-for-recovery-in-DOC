function cache = get_cache(iswake,kmax)
	% Cache for the tent code
	% Fixed alpha and beta values
	% Unlike mcmc.get_cache, this version is able to operate with fixed alpha
	% and beta, so it computes L 
	cache.p = params(iswake);
	cache.w = 2*pi*linspace(0,100,5000);
	cache.L = 1./((1-1i*cache.w/cache.p.alpha(1)).*(1-1i*cache.w/cache.p.beta(1)));
	cache.L2 = cache.L.^2;
	L3 = cache.L2.*cache.L;
	Mtot = exp(1i*cache.w*cache.p.t0);
	cache.L2Mtot = cache.L2.*Mtot; 
	cache.L3Mtot = L3.*Mtot; 
	cache.gamma_factor = (1-1i*cache.w./cache.p.gammae).^2;
    Lx = 0.5; % linear dimensions of cortex (assume square)
    k0 = 10; % Volume conduction parameter
    dk = 2*pi/Lx;
    m_rows = -kmax:kmax; 
    n_cols = -kmax:kmax; 
    [kxa,kya] = meshgrid(dk*m_rows,dk*n_cols); 
    k2 = kxa.^2+kya.^2;
    cache.k2u_re2 = cache.p.re.^2.*unique(k2(:)); % Unique values of k^2 for stability testing
	cache.z_factor = cache.p.alpha(1).*cache.p.beta(1)./(cache.p.alpha(1)+cache.p.beta(1)).^2;