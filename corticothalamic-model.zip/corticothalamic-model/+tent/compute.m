function [x,y,z,u] = compute(a,b,t0,gammae)
	% [x,y,z,u] = compute(alpha,beta,t0,gammae)
	%
	% Given alpha and beta, t0, gammae , compute the tent
	if nargin == 0
		p = model.params(1);
		a = p.alpha(1);
		b = p.beta(1);
		t0 = p.t0;
		gammae = p.gammae;
	end

	stab_w=2*pi*linspace(0,100,5000).'; % High res array, 0 to 200Hz with 10000 points
	stab_L = 1./((1-1i*stab_w/a).*(1-1i*stab_w/b));
	stab_gamma_prefactor = (1-1i*stab_w/gammae).^2;

	nx=250;
	ny=2*nx-1;
	[x,y] = meshgrid(linspace(0.0001,1.3999,nx),linspace(-1.1999,0.9999,ny));

	z=ones(size(x)); % Store the *index* of z, multiply by dz 
	u=zeros(size(x));

	nz = 100;
	z_vals = linspace(0,1,nz);
	zprime_factor = (a+b)^2/(a*b); % Effectively Gsrs
	z_cache = 1+bsxfun(@times,stab_L.*stab_L,z_vals*zprime_factor);
	one_plus_z_vals_zprime_mtot = bsxfun(@times,exp(1i*stab_w*t0),1+z_vals*zprime_factor);


	count = 0;
	zz = 1; % Initial unstable z

	% Preallocate these for compiling
	d1 = ones(size(stab_w));
	d = ones(size(stab_w));

	for jy = size(x,1):-1:1 % This is actually over the y direction

		count = count + 1;
		% if mod(count,2)
		% 	x_idxs = size(x,2):-1:1;
		% else
		 	x_idxs = 1:size(x,2);
		% end

		for jx = x_idxs

			xx = x(jy,jx);
			yy = y(jy,jx);

			x_preterm = (stab_gamma_prefactor) - xx;

			if (xx+yy)>1
				continue
			end
			
			d = (x_preterm).*z_cache(:,zz) - yy.*one_plus_z_vals_zprime_mtot(:,zz);
			stab=d(1)>0 && ~any(real(d(2:end))<0 & imag(d(2:end)).*imag(d(1:end-1))<0);

			if stab == 0 && zz == 1 % Unstable at zero frequency
				continue
			elseif stab == 1 
				dz = 1;
				ascending = true;
			else 
				dz = -1;
				ascending = false;
			end

			finished = false;
			while ~finished && ((ascending && zz < nz && zz >= 1) || (~ascending && zz <= nz && zz > 1))
				zz = zz + dz;

				d1 = (x_preterm).*z_cache(:,zz) - yy.*one_plus_z_vals_zprime_mtot(:,zz);
				stab=d1(1)>0 && ~any(real(d1(2:end))<0 & imag(d1(2:end)).*imag(d1(1:end-1))<0);

				if ascending && ~stab % If we have reached the first unstable point
					% d was the last stable one
					[~,idx] = min(abs(d1)); 
					u(jy,jx) = stab_w(idx);
					z(jy,jx) = zz;
					finished = true;
				elseif ~ascending && stab % Otherwise, we were descending and reached the first stable point
					zz = zz - dz;
					[~,idx] = min(abs(d)); 
					u(jy,jx) = stab_w(idx);
					z(jy,jx) = zz;
					finished = true;
				else
					d = d1;
				end
			end

			if ~finished % We hit the bottom when descending, or the top when ascending
				z(jy,jx) = zz;
				if ascending
					[~,idx] = min(abs(d1)); 
					u(jy,jx) = stab_w(idx);
				else
					[~,idx] = min(abs(d)); 
					u(jy,jx) = stab_w(idx);
				end
			end

		end
	end

	dz = z_vals(2)-z_vals(1);
	z = (z-1)*dz;
	u = u/(2*pi);

	if nargout == 0
		figure
		mesh(x,y,z,u)
		colorbar
		xlabel('x'), ylabel('y'), zlabel('z')
		title(sprintf('\\alpha=%.0f, \\beta=%.0f, t_0=%.0fms, \\gamma_e=%.0f',a,b,t0*1000,gammae))
		set(gca,'View',[95 34]);
		set(gca,'CLim',[0 50]);
		set(gca,'XLim',[0 1.5],'YLim',[-1 1])
	end