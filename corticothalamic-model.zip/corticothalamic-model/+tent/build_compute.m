codegen corticothalamic-model/+tent/compute.m -args {1,1,1,1}
rmdir('codegen','s')
movefile('compute_*','corticothalamic-model/+tent/')
