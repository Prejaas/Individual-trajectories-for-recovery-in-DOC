function [x,y,z,z_out,u] = wholespace(a,b,t0,gammae)
	% [x,y,z,u] = wholespace(alpha,beta,t0,gammae)
	%
	% This function scans the entire grid for stability
	% This allows the overhanging region of stability near X=1 to
	% be resolved (whereas the tent surface cannot include concave regions)
	tic;
	if nargin == 0
		p = model.params(1);
		a = p.alpha(1);
		b = p.beta(1);
		t0 = p.t0;
		gammae = p.gammae;
	end


	stab_w=2*pi*linspace(0,50,10000).'; % High res array, 0 to 200Hz with 10000 points
	stab_L = 1./((1-1i*stab_w/a).*(1-1i*stab_w/b));
	stab_gamma_prefactor = (1-1i*stab_w/gammae).^2;

	nx=30;
	ny=2*nx-1;
	nz = nx;

	xl = [0.0001 1.4];
	yl = [-1.2 1.2];
	zl = [0 1];

	xl = [0.75 1.3];
	yl = [-0.5 0];
	zl = [0 1];

	z_vals = linspace(zl(1),zl(2),nz);
	[x,y,z] = meshgrid(linspace(xl(1),xl(2),nx),linspace(yl(1),yl(2),ny),z_vals);

	fz = @(x)  x+0.01*randn(size(x));
	x = fz(x);
	y = fz(y);
	z = fz(z);
	z(z<0) = 0;
	x(x<0) = 0;

	z_out = zeros(size(z));
	u = zeros(size(z));

	zprime_factor = (a+b)^2/(a*b); % z*zprimefactor=-Gsrs = ztwiddle
	z_cache = 1+bsxfun(@times,stab_L.*stab_L,z_vals*zprime_factor);
	one_plus_z_vals_zprime_mtot = bsxfun(@times,exp(1i*stab_w*t0),1+z_vals*zprime_factor);

	count = 0;

	for jx = 1:size(x,1)
		for jy = 1:size(x,2)
			for jz = 1:size(x,3)


				xx = x(jx,jy,jz);
				yy = y(jx,jy,jz);
				x_preterm = (stab_gamma_prefactor) - xx;

				d = (x_preterm).*z_cache(:,jz) - yy.*one_plus_z_vals_zprime_mtot(:,jz);
				stab=d(1)>0 && ~any(real(d(2:end))<0 & imag(d(2:end)).*imag(d(1:end-1))<0);
				
				z_out(jx,jy,jz) = stab;
				[~,idx] = min(abs(d)); 
				u(jx,jy,jz) = stab_w(idx);
			end
		end
	end

	toc;
	flt = z_out(:)==true;
	scatter3(x(flt),y(flt),z(flt),20,u(flt))
	set(gca,'XLim',[0 1.5],'YLim',[-1.5 1.5],'ZLim',[0 1])




	a = [x(flt),y(flt),z(flt)];
	[V,S] = alphavol(a,Inf);
	
	k = S.bnd;
	map = unique(k(:));
	map(:,2) = 1:length(map); % First col is the index in k, second row is the new index
	reconstruct.vertices = a(map(:,1),:); % A final list of vertices
	reconstruct.faces = arrayfun(@(b) map(find(map(:,1)==b),2),k);

	hold on
	p = trisurf(reconstruct.faces,reconstruct.vertices(:,1),reconstruct.vertices(:,2),reconstruct.vertices(:,3));

	[x1,y1,z1,u1] = tent.compute;
	mesh(x1,y1,z1,u1);