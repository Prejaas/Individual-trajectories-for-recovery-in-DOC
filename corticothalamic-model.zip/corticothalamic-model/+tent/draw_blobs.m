function draw_blobs(selected_states,alpha_override)
	% This function will superimpose blobs on the tent diagram
	% It expects a cached file "corticothalamic-model/+tent/population_blobs.mat"
	% Example usage
	% tent.surface_hg2
	% tent.draw_blobs({'ec','n3'},0.1)
	% The blobs stored in population_blobs.mat correspond to those shown in
	% Abeysuriya et. al. 2015 (Physiologically based state estimation...)

	analysis_states = {'eo','ec','rem','n1','n2','n3','n2s'};

	if nargin < 2 || isempty(alpha_override)
		alpha_override = [];
	end

	if nargin < 1 || isempty(selected_states)
		selected_states = analysis_states;
	end
	
	if ~exist('corticothalamic-model/+tent/population_blobs.mat')
		% Regenerate the cache
		d = load('romesh-large-files/pdb_specvalid.mat','reconstruct');
		for j = 1:length(analysis_states)
			state.(analysis_states{j}) = d.reconstruct.(analysis_states{j});
		end
		save('corticothalamic-model/+tent/population_blobs.mat','state');
	end

	data = load('corticothalamic-model/+tent/population_blobs.mat');

	for j = 1:length(analysis_states)
		if isempty(selected_states) || any(strcmp(analysis_states{j},selected_states))
			r = data.state.(analysis_states{j});

			if alpha_override
				alph = alpha_override;
			else
				alph = r.alpha;
			end

			p = trisurf(r.faces,r.vertices(:,1),r.vertices(:,2),r.vertices(:,3),'Parent',gca,'FaceColor',r.colour,'FaceAlpha',alph,'EdgeColor','none','UserData','blob');
			hold on
		end
	end