function varargout=idl_surface
    % This is the original implementation of the tent stability code
    % written by James Roberts (pre-2010). James in turn wrote this function
    % based on the original IDL code used to make the tent diagram in 2002.
    
    p = model.params(1);
    alpha = p.alpha(1);
    beta = p.beta(1);
    t0 = p.t0;
    gamma = p.gammae;

    omega=2*pi*linspace(0,200,10000); % High res array, 0 to 200Hz with 10000 points
    lomega2=1./((1-1i*omega/alpha).*(1-1i*omega/beta)).^2;
    gammaterm=(1-1i*omega/gamma).^2;
    phase=exp(1i*omega*t0);

    nx=26;
    nz=nx;
    ny=2*nx-1;
    x=linspace(0.0001,1.3999,nx);
    y=linspace(-1.1999,0.9999,ny);
    z=zeros(nx,ny);
    u=zeros(nx,ny);

    w0=w(0,0,0);
    ycc=-0.25;
    ymm=-1.13;
    zsc=(alpha+beta)^2/(alpha*beta); % Maximal value for |Gsrs|
    %zsc=8;
    for j=1:nx
        fprintf(1,'%d ',j)
        for k=1:ny
            if y(k)==0
                % Isolated cortex: u is f(alpha, beta)
                z(j,k)=1.0;
                u(j,k)=(alpha*beta)^0.5/(2*pi);
            else
                if y(k)>(1-x(j)) ||  y(k)<(ycc-ymm)*x(j)/(1-ycc)+ymm+0.20*x(j)*(1-ycc-x(j))
                    % ;; No fixed points: u is not defined
                    z(j,k)=0;
                    u(j,k)=NaN;
                else 
                    % Stability is conditional on z: search for onset of instability
                    dz=zsc/(nz-1);
                    zr=0;
                    while (abs(w(x(j),y(k),-zr)-w0)<0.5) && (zr<zsc)
                        zr=zr+dz;
                    end
                    z(j,k)=zr/zsc;
                    % ;; Locate frequency, u, for which |q^2| is a minimum
                    q2=(1-1i*omega/gamma).^2-x(j)-y(k)*phase.*(1+zr)./(1+zr*lomega2);
                    %q2=gammaterm-x(j)-y(k)*phase.*(1+zr)./(1+zr*lomega2);
                    u(j,k)=omega(abs(q2)==min(abs(q2)))/(2*pi);
                    % next line temporary
                    if z(j,k)>0.68
                        %u(j,k)=(alpha*beta)^0.5/(2*pi);
                    end
                end
            end

            % next line temporary
            if ((y(k)<ycc) && (y(k)>ycc-0.2) && (z(j,k)<0.2) && (u(j,k)>0) && (x(j)>1))
                %u(j,k)=3.0 ;
            end
        end
    end
    fprintf(1,'\n')

    mesh(x,y,z',u')
    colorbar
    xlabel('x'), ylabel('y'), zlabel('z')

    if nargout==4,
        varargout{1}=x;
        varargout{2}=y;
        varargout{3}=z;
        varargout{4}=u;
    end

    function out=w(x,y,sr)
    % winding number of q2
        q2=(gammaterm-x).*(1-sr*lomega2)-y*phase*(1-sr);
        w=imag(sum(q2(2:end)./q2(1:end-1)));
        out=w/pi;
    end

end