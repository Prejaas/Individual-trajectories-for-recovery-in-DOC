function parameter_sweep_nroots(p, m)
% DESCRIPTION: Parameter sweep to find regions with different number of roots and
%              associated variables like stab.
%  
% ARGUMENTS:
%         p           -- is a params structure with parameters for the
%                        corticothalamic model
%         m           -- handle to writable matfile 
%
% OUTPUT: 
%         None        -- the results are saved in m
%
% REQUIRES:
%        corticothalamic-model/
%                             model.ve_root
%                             model.params.complete_gab
%        generate_matfile_options
%        
% USAGE:
%{    
      load('steady_states_parameters.mat', 'ss')
      fname = 'local_test';
      inopt.interval = 1e-2;
      inopt.blocks = 4;
      inopt.these_axes = [1, 2, 3, 4];         % explore only the first four axes
      inopt.slice_values = [0.0, 0.0, 0.0, 0]; % set to zero the parameters along the other axes
      inopt.pbs = [];                          % cluster flag
      % generate the file
      myfile = utils.io.generate_matfile_options(fname, ss, inopt);
      parameter_sweep_nroots(ss, myfile)
%}
%
% PSL Jun 2017

% get the maximum number of workers that we can use
c = parcluster('local'); 
nw = c.NumWorkers      ;

% open a pool with that number, unless it already exists
current_pool = gcp('nocreate');

if isempty(current_pool)
    parpool('local', nw)
elseif current_pool.NumWorkers < nw
    delete(current_pool)
    parpool('local', nw)
end

% These variables should exist in the file 
options  = m.options;
blocks   = options.iteration.blocks;

% get ranges of nu
nus = m.nus;

% make them local variables for imporoved readability
nuee = nus{1};
nuei = nus{2};
nues = nus{3};
nuse = nus{4};
nusr = nus{5};
nusn = nus{6};
nure = nus{7};
nurs = nus{8};

% free memory
clear nus

nroot_full_shape = [length(nuee), length(nuei), length(nues), length(nuse), ...
                    length(nusr), length(nusn), length(nure), length(nurs)];
linearsize   = prod(nroot_full_shape);


    if options.errors.correct_results % means that we should run the parameter sweep for certain points in the space
        % Check that v is equally spaced
        % Find places when contiguous blocks finish
        lidx = options.errors.lidx; % linear indices of bad_roots
        idx1 = find(diff(lidx)> 1);
        idx2 = idx1 + 1;
        idx1 = [idx1; length(lidx)];
        idx2 = [1; idx2];

        % start:stop indices of contiguous blocks
        idx = [idx2 idx1];

        for bb = 1:length(idx)
            v=idx(bb,1):idx(bb, 2);

            nroots = zeros(length(v), 1);
            % at most nroots
            stab  = uint8(inf(1, 5, length(v))); 

            % parallel for
            parfor ii = 1:length(v)      
               temp = struct();
               [temp.idx1, temp.idx2, ...
                temp.idx3, temp.idx4, ...
                temp.idx5, temp.idx6, ...
                temp.idx7, temp.idx8] = ind2sub(nroot_full_shape, v(ii));

               % This is where all the magic happens. Get all the variables.
               [temp.nroots, ~, ~, ~, ~, temp.stab, ...
                ~] = parsweep.get_ve_roots(p, [nuee(temp.idx1), nuei(temp.idx2), ...
                                                           nues(temp.idx3), nuse(temp.idx4), ...
                                                           nusr(temp.idx5), nusn(temp.idx6), ...
                                                           nure(temp.idx7), nurs(temp.idx8)], ...
                                                            -0.1:0.0001:12.4);
                 nroots(ii)   = temp.nroots;
               % at most nroots
                 stab(:, :,  ii)      = temp.stab;
            end


            % save partial results 
            m.nroots(start:stop,1)           = uint8(nroots); % save some space
            m.stab(1, 1:5, start:stop)       = stab;
        end


    else
        % compute number of blocks so mod(linearsize, blocks) == 0
        if mod(linearsize, blocks) ~=0       % if the suggested number of blocks does not work
           f = unique(factor(linearsize));

           % NOTE: might need a larger number
           blocks = prod(f(end-2:end));
           options.iteration.blocks = blocks;
        end

        block_size   = linearsize/blocks;


        % Save some important variables in the file
        try 
            % if the file already had information about kk
            kk_start = options.iteration.kk+1;

        catch 
            % if it did not, populate options
            options.shape.nroot_full_shape = nroot_full_shape;
            options.iteration.block_size = block_size;
            options.iteration.kk = 0;
            m.options = options;
            kk_start  = options.iteration.kk;
            m.p = p;
        end


        for kk=kk_start:blocks-1
            start =  kk*block_size+1;
            stop  = (kk+1) * block_size;
            v = start:stop;

            % Preallocate space for ouput. It may give memory errors is block_size
            % is too big (how big?).

                nroots = zeros(length(v), 1);
                bad_root = zeros(length(v), 1);
                stab  = uint8(inf(1, 5, length(v)));

            
            % parallel for
            parfor ii = 1:length(v)      
               temp = struct();
               [temp.idx1, temp.idx2, ...
                temp.idx3, temp.idx4, ...
                temp.idx5, temp.idx6, ...
                temp.idx7, temp.idx8] = ind2sub(nroot_full_shape, v(ii));

               % This is where all the magic happens. Get all the variables.
               [temp.nroots, ~, ~, ~, ~, temp.stab, ~, ~, ~,...
                ~] = parsweep.get_ve_roots(p, [nuee(temp.idx1), nuei(temp.idx2), ...
                                                           nues(temp.idx3), nuse(temp.idx4), ...
                                                           nusr(temp.idx5), nusn(temp.idx6), ...
                                                           nure(temp.idx7), nurs(temp.idx8)], ...
                                                           -0.1:0.0001:5.4); %ve
                 nroots(ii)   = temp.nroots;
               % at most nroots
                 stab(:, :,  ii)      = temp.stab;
            end

            % save partial results 
            m.nroots(start:stop,1)           = uint8(nroots); % save some space
            m.stab(1, 1:5, start:stop)       = stab;
           
            % save number of iteration to restart if necessary
            options.iteration.kk = kk;
            m.options = options;

        end
    end
        
    
end
