function [nroots, phia, gab, gabcd, xyz, stab, pe, q2, fpeaks, bad_root] = get_ve_roots(p, nus, ve)
% DESCRIPTION: This function is used get the number of roots and all other 
%              variables relevant to steady states and to comply with 'transparency'
%              required by a parfor loop. This function makes use of the
%              corticothalamic-model module.

% The ouput always has the same size, even if there are less than 5
% roots.
% at most 5 x 8 / nroots x number of nus
gab   =  inf(5, 8);        
% at most 5 x 5 / nroots x number of gabcd
gabcd =  inf(5, 5); 
% at most 5 x 3 / nroots x xyz coordinates
xyz   =  inf(5, 3);
% at most nroots
stab  =  inf(1, 5);
% at most nroots x 3 (e,r,s)
phia  = -inf(5, 3); % -inf will flag a bad result
% at most nroots x 1000
pe    = inf(5, 1000);
% q2
q2    = inf(5, 1000);


fpeaks = inf(5, 2);  % frequency of the two largest power peaks         

% To check weather there is a problem with the numerical results, 
% check with the number of roots at that point.
        
% number of roots should be odd
bad_roots = [0, 2, 4, 6, 8];
bad_root = 0;
p.nus = nus;
    
% Get all the important things.
%                   ve range        stability_freqs    validate phis
p.compute_steady_states(ve)
    
% Output all the variables that were computed by compute_gab
nroots = p.nroots; 

    
if nroots > 0
    gab(1:nroots,   :)   = p.gab;    % double
    gabcd(1:nroots, :)   = p.gabcd;  % double
    xyz(1:nroots,   :)   = p.xyz;    % double
    phia(1:nroots,  :)   = p.phia;   % double
    stab(:, 1:nroots)    = p.stab;   % uint8 - fake roots will be 255
    pe(1:nroots, :)      = p.pe;     % double 
    q2(1:nroots, :)      = p.q2;     % double 
    % find 2 largest peaks
    for nn=1:nroots
        [~, locs] = findpeaks(pe(nn, :), p.f, 'NPeaks', 2, 'SortStr', 'descend');
        if isempty(locs)
           [~, idx] = max(pe(nn, :));
           fpeaks(nn, : ) = [p.f(idx), p.f(idx)]; % if there are no peaks, take the freq of the max(pe)
        else
           fpeaks(nn, :)  = locs;
        end
    end
end
if any(p.nroots == bad_roots)
    % flag it as a bad solution to be re run;
    bad_root = 1;
end
    
end