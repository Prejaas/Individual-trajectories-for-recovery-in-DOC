%% DESCRIPTION:  This functions produces the linear vectors for the eight 
%                dimensions of the cortricothalamic model:
% ARGUMENTS:
%         p                 -- params structure with property 'range_nus'
%         interval          -- step to generate a range 
%         these_axes        -- axes to explore fully
%         slice_values(optional)      -- parameter values for one slice in other_axes
% OUTPUT: 
%         nus        -- 8 x 1 cell array with the linearly spaced ranges for each nu  
%         other_axes -- the axes for which the value of nus has been fixed.
%
% REQUIRES:
%        
% USAGE:
%{

%}
function varargout = get_nu_ranges(p, interval, these_axes, varargin)

if ~isempty(varargin)
    slice_values = varargin{1};
end
shape = [];
nus = cell(8, 1);
nelements = 1;
if length(interval) == 1
    for ii=1:length(these_axes)

        nus{these_axes(ii)} =   p.range_nus(1, these_axes(ii)):interval:p.range_nus(2, these_axes(ii)); % V s
    end
else    
    for ii=1:length(these_axes)
        nus{these_axes(ii)} =   p.range_nus(1, these_axes(ii)):interval(these_axes(ii)):p.range_nus(2, these_axes(ii)); % V s
        nelements = nelements*length(nus{these_axes(ii)});
        shape = [shape, length(nus{these_axes(ii)})];
    end
end
disp(['Number of elements is: ' num2str(nelements)])
disp('Shape is: ')
shape

other_axes = setxor(these_axes, 1:8);

if ~isempty(other_axes)
    for ii=1:length(other_axes)
        nus{other_axes(ii)} =  slice_values(ii);
    end
    varargout{2} = other_axes;
end

varargout{1} = nus;
end % functions