%% DESCRIPTION: Transcendental steady state equation of the corticothalamic 
%  model (EIRS) expressed as a fn of firing rate qe
%  Equivalent to model.ve_root.m from corticothalamic
% ARGUMENTS:
%         qe      -- Initial guess 
%         nus     -- Vector with the eight corticothalamic synaptic weights
%         theta   -- Voltage threshold
%         qmax    -- Maximum firing rate
%         sigma   -- Width of transition
%         variant -- Variant of the steady state equation. '' or 'derivative'
%
% OUTPUT: 
%         Fy or dFy -- trascendental equation to find the steady states / or
%                     its derivative.
%         Fy_minus -- lower bound (optional)
%         Fy_plus  -- upper bound (optional)
%
% REQUIRES:
%         sigmoid()
%
% USAGE:
%{
%      N = 1000;
%      qe = linspace(0, 340, N);
%      theta = 0.003;  % mV
%      sigma = 0.001;  % mV
%      qmax  = 340;    % /s
%      nus   = [0.0078   -0.0099    0.0009    0.0027   -0.0013    0.0066 0.0002    0.0001];
%      [Fy, Fyp, Fym] = ss_model.qe_root(qe, nus, qmax, theta, (pi/sqrt(3))*sigma);
%      figure, plot(qe, [Fy; Fy_plus; Fy_minus);
%      hold on;
%      [dFy] = ss_model.qe_root(qe, nus, qmax, theta, (pi/sqrt(3))*sigma, 'derivative');
%      figure, plot(qe, [Fy; Fy_plus; Fy_minus);
%      
%}
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [varargout] = qe_root(qe, nus, qmax, theta, sigma, variant)%#OK

if nargin < 6,
    variant = '';
end
  
nuee = nus(1);
nuei = nus(2);
nues = nus(3);
nuse = nus(4);
nusr = nus(5);
nusn = nus(6);
nure = nus(7);
nurs = nus(8);

A = nuee + nuei;
B = nurs / nues;

% Sigmoid
import model.sigmoid
S   = @(V) sigmoid(V, qmax, theta, sigma, '');
% First derivative of Sigmoid
dS  = @(V) sigmoid(V, qmax, theta, sigma, 'first'); 
% Inverse of Sigmoid
iS  = @(Q) sigmoid(Q, qmax, theta, sigma, 'inverse'); 
% First derivative of Inverse of Sigmoid
diS = @(Q) sigmoid(Q, qmax, theta, sigma, 'inv_first');

 
% This equation assumes phin = 1; /s
switch variant
    case{''}
        varargout{1}  = iS(qe) - A .* qe - nues .*S(nuse  .* qe + nusr.* S(nure .*qe + B .* (iS(qe) - A .* qe)) + nusn);
        % Bounded below by Fp_minus
        varargout{2}  = iS(qe) - A .* qe - nues .* qmax;
        % Bounded above by Fp_plus
        varargout{3}  = iS(qe) - A .* qe;
    case{'derivative'}
        
        if ~isnan(B),
            varargout{1} = diS(qe) - A + (-nuse * dS(nuse  .* qe + nusr.* S(nure .*qe + B .* (iS(qe) - A .* qe)) + nusn)) .* ((nuse + nusr .* dS(nure .*qe + B .* (iS(qe) - A .* qe)) .* (nure + B .* (diS(qe) - A))));
        else
            varargout{1} = diS(qe) - A; 
        end

end

end