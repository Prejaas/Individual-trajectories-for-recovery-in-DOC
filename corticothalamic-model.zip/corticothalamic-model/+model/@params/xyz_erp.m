function [t,x] = erp(self)
	% Return the erp - currently a placeholder
	t = linspace(0,1,100);
	x = zeros(size(t));