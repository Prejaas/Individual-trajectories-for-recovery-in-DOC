function compute_steady_states(p,ve_range)
% compute steady states given the parameter values in p
% Given a point struct p without Gab, fill

% The optional argument neighbour decides behaviour for multiple solutions
% If neighbour = 1, and there are already phi values in the point, then
% the code will pick only the ve_root that is most consistent with the existing
% firing rates, and the others will be deleted

% The optional argument velimit is a parameter that specifies the range
% over which Ve should be searched- dramatically increases performance if
% known in advance

% Optional argument stab_freq specifies the frequencies to evaluate stability at
% If stab_freq is a scalar e.g., stab_freq==1, then the default frequency range
% will be used

% Optional argument state specifies which limits from limits.m to use
% This is passed to limits() via validate() unless is empty.

p.disable_set = true;

% Clear all of the fields that this function will populate
p.nroots = 0;
p.gab    = [];
p.gabcd  = [];
p.xyz    = [];
p.ve     = [];
p.stab   = [];
p.pe     = [];
p.q2     = [];
if isempty(p.nus) || size(p.nus,1) > 1
    p.disable_set = false;
    return
end

[ves,~] = utils.allroots(@model.mex_ve_root,ve_range,p.nus,p.theta,p.sigma,p.qmax);
		
if isempty(ves) % If no roots were found
    p.phia = [];
    return
end
	
% Preallocate space for phis
phiv = zeros(length(ves),3); % phie, phir, phis

% Calculate all of the phi values
for j = 1:length(ves)
    % Calculate the firing rates
    phiv(j,1) = model.sigm(ves(j),p);
    vr        = p.nus(7)*phiv(j,1)+(p.nus(8)/p.nus(3))*(ves(j)-(p.nus(1)+p.nus(2))*phiv(j,1));
    phiv(j,2) = model.sigm(vr,p);
    vs        = p.nus(4)*phiv(j,1)+p.nus(5)*phiv(j,2)+p.nus(6);
    phiv(j,3) = model.sigm(vs,p);
end

% Preallocate storage for other parameters
xyzs   = zeros(length(ves),3); % x,y,z
stab   = zeros(1,length(ves));

% Evaluate rho
rhoe = phiv(:,1).*(1-phiv(:,1)/p.qmax)/p.sigma;
rhor = phiv(:,2).*(1-phiv(:,2)/p.qmax)/p.sigma;
rhos = phiv(:,3).*(1-phiv(:,3)/p.qmax)/p.sigma;
rhoset = [rhoe rhoe rhoe rhos rhos rhos rhor rhor];


% Calculate the G_ab
gabs = repmat(p.nus, length(ves), 1).*rhoset;
% Calculate G_abcd
gabcds =  [gabs(:,1), gabs(:,2),gabs(:,3).*gabs(:,4), gabs(:,3).*gabs(:,5).*gabs(:,7), gabs(:,5).*gabs(:,8)];

% Compute xyz coordinates
% NB. gabs(j,1) = gee, gabs(j,2) = gei etc.
% x
xyzs(:,1) = gabs(:,1) ./ (1 - gabs(:,2));
% y
xyzs(:,2) = (gabs(:,3).*gabs(:,4) + gabs(:,3).*gabs(:,5).*gabs(:,7)) ./ ((1 - gabs(:,5).*gabs(:,8)).* (1 - gabs(:,2)));
% z
xyzs(:,3) = -gabs(:,5).*gabs(:,8).*p.alpha(5) .* p.beta(5) ./ (p.alpha(5) + p.beta(5))^2;
    
% Calculate stability
pe = zeros(length(ves), 1000);
for jj = 1:length(ves) % For each of the Ve roots
    p.gab = gabs(jj,:); % Insert current set of Gab being tested
    stab(jj) = p.is_stable;
    % compute spectrum
    q2(jj, :) = p.compute_q2;
    [~, pe(jj, :)]   = p.compute_linear_spectrum;
end

p.q2     = q2;
p.pe     = pe;
p.ve     = ves;
p.gab    = gabs;
p.gabcd  = gabcds;
p.xyz    = xyzs;
p.phia   = phiv;
p.nroots = length(ves);
p.stab   = stab;
p.disable_set = false;
end
