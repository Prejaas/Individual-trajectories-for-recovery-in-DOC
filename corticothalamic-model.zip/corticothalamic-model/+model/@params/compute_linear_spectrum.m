function [f,P] = compute_linear_spectrum(p)

    % root_index: when p has many solutions choose the solution to compute
    % the power spectrum

    root_index = 3;
    if isempty(p.gab)  % no gains available
        error('Need gab')
    elseif size(p.gab,1) > 1
        gab = p.gab(root_index, :);
    else
        gab = p.gab;
    end
    
    if isempty(p.f)
        fmax = 45;
        nw   = 1000; % Sufficient for spectrum
        f = linspace(0,fmax,nw); 
    else
        f = p.f;
    end
    w = f*2*pi;
    %dw = w(2)-w(1);
    kmax = 6;
    Lx = 0.5; % linear dimensions of cortex (assume square)
    k0 = 10;  % Volume conduction parameter
    dk = 2*pi/Lx;
    m_rows = -kmax:kmax; 
    n_cols = -kmax:kmax; 
    [kxa,kya] = meshgrid(dk*m_rows,dk*n_cols); 
    k2 = kxa.^2+kya.^2;
    k2u = unique(k2(:));
    k2u = [k2u histc(k2(:),k2u)]; % First col is the k2 value, second is how many times it appeared
    
    P = zeros(size(w));

    Dew = (1-1i*w./p.gammae).^2;

    Di =1;
    [Jee,Jei,Jese,Jesre,Jsrs,Jesn] = get_Jabcd(p, w, gab);


        for j = 1:size(k2u,1) % EFFICIENT CALCULATION
            k = k2u(j,1);
            De = Dew + k*p.re.^2;        
            A = De.*(Di-Jei)./Di - Jee;

            this_phie = Jesn.*p.phin./(A.*(1-Jsrs) - Jese - Jesre);
            
            P = P + k2u(j,2).*abs(this_phie).^2 * exp(-k/k0^2); % For use with the efficient way
            %P = P + k2u(j,2).*abs(this_phie).^2; % For use with the efficient way, NO VOLUME CONDUCTION
            %P = P + abs(this_phie).^2 * exp(-k/k0^2); % For use with the full calculation
        
        end % END EFFICIENT CALCULATION

        P = P.*dk.^2;   % Multiply by dk then sum to get the integral over k
        P = P(:).'*2*pi; % Convert to P(f)
end
function [Jee,Jei,Jese,Jesre,Jsrs,Jesn] = get_Jabcd(p,w,gab)
    L = @(idx) 1./((1-1i*w/p.alpha(idx)).*(1-1i*w/p.beta(idx)));
    M = exp(1i*w*p.taues); % Assume Mes = Mse

    % It is important to use the G_ab if they are available
    % because the G_ab define a value for G_sn which allows the
    % normalization with NFTsim to be correct.
    % The 5 gains do not specify the normalization of the power spectrum
        % Use the 8 gains
        Jee = L(1).*gab(1);
        Jei = L(2).*gab(2);
        Jes = L(3).*gab(3).*M;
        Jse = L(4).*gab(4).*M;
        Jsr = L(5).*gab(5);
        Jsn = L(6).*gab(6);
        Jre = L(7).*gab(7).*M;
        Jrs = L(8).*gab(8);

        Jese  = Jes.*Jse;
        Jesre = Jes.*Jsr.*Jre;
        Jsrs  = Jsr.*Jrs;
        Jesn  = Jes.*Jsn;
end
