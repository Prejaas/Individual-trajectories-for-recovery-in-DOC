%% DESCRIPTION: Returns either sigma function, its inverse, or its derivative. 
%
% ARGUMENTS:
%         arg   -- Vector of values at which we want to evaluate function (q or v). 
%         qmax  -- Peak value
%         theta -- Midpoint of transition
%         sigma -- width of transition
%         variant -- '' || 'inverse' || 'first' || || 'second' ||
%                    'inv_first' ...
%
% OUTPUT: 
%         S -- The 'variant' of the sigmoid function evaluated at 'arg'
%
% REQUIRES:
%        none
%
% USAGE:
%{
      N = 100;
      v = linspace(0, 6, N);
      theta = 3; % mV
      sigma = 1; % mV
      S = sigmoid(v, 1, theta, sigma);
      figure, plot(v, S); 
%}
%
% MODIFICATION HISTORY:
%     SAK(17-11-2009) -- Original.
%     SAK(04-12-2009) -- Added inverse...
%     SAK(05-01-2010) -- Added derivative...
%     PSL(02-12-2016) -- Added higher order derivatives of the function and
%                        its inverse ...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function S = sigmoid(arg,qmax,theta,sigma,variant)
  if nargin<5,
    variant = '';
  end
  if nargin<4,
     theta = 2^-1;
  end
  if nargin<3,
    sigma = 2^-3;
  end
  if nargin<2,
    qmax = 1;
  end

  PiOnSqrt3 = 1.813799364234217836866491779801435768604278564;
  
  S = inf(size(arg));
  switch lower(variant),
    case{'', 'sigmoid'}
      v = arg;
      S = qmax ./ (1 + exp(-PiOnSqrt3.*((v-theta)./sigma)));
    case {'inverse'},
      q = arg;          % Only for consistency with the notation
      S = theta + (sigma/PiOnSqrt3) .* (log(q) - log(qmax-q));
    case{'inv_first'}   % first order derivative wrt Q
      q = arg;
      S = (sigma/PiOnSqrt3) * ( 1./q + 1./(qmax - q));  
    case{'inv_second'}  % second order derivative wrt Q
      q = arg;
      S = (sigma/PiOnSqrt3) * (1./(qmax - q).^2 - 1./q.^2);
    case{'inv_third'}
      q = arg;
      S = 2*(sigma/PiOnSqrt3) * (1./(qmax - q).^3 + 1./q.^3);
    case{'first'}     % first order derivative wrt V
      v = arg;
      w = exp(-PiOnSqrt3.*((v-theta)./sigma));
      S = (PiOnSqrt3.*qmax./sigma) .* w ./ ((1+w).*(1+w));
    case{'second'}    % second order derivative wrt V
      v = arg;
      w  = exp(-PiOnSqrt3.*((v-theta)./sigma));
      w2 = exp(-2*PiOnSqrt3.*((v-theta)./sigma));
      S = (((2*qmax*(PiOnSqrt3)^2) / theta^2) .* w2) ./ ((1 + w) .* (1 + w) .* (1 + w))  - ...
          ((qmax*(PiOnSqrt3)^2) / theta^2) .* w ./ ((1 + w) .* (1 + w));
    case{'third'}    % third order derivative wrt V
      v  = arg;  
      w  = exp(-PiOnSqrt3.*((v-theta)./sigma));
      w2 = exp(-2*PiOnSqrt3.*((v-theta)./sigma));
      w3 = exp(-3*PiOnSqrt3.*((v-theta)./sigma));
      K = ((qmax*(PiOnSqrt3)^3) / theta^3);
      S = K .* w ./ ((1 + w) .* (1 + w)) -  6 * K .* w2 ./ ((1 + w) .* (1 + w) .* (1 + w)) + 6 * K .* w3 ./ ((1 + w) .* (1 + w) .* (1 + w) .* (1 + w));        
    otherwise
      error(['corticothalamic-model:' mfilename ':UnknownVariant'],'Requested and unknown variant of the sigmoid function');
  end
    
end 
