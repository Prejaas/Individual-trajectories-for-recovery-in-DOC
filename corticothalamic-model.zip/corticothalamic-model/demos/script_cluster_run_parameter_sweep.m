% Creates a file and runs locally to test all the functions used in a 
% par(allel) parameter sweep. 
% Total runtime ~ 80 s  on Pau's c**ppy laptop Latitude E5450 
% Matlab R2015b
% Numworkers: 2 workers

% Add path to matlab
%addpath(genpath('/headnode2/paula123/Code/NeuroField/corticothalamic-model'))
debug = 1;

if debug
    pbs_array_idx  = '42';
    addpath(genpath('/import/headnode2/paula123/Code/NeuroField/corticothalamic-model'))
else
    % Get index to switch cases if running several cases on the cluster
    pbs_array_idx  = getenv('PBS_ARRAYID');
end

    
pbs_idx        = str2double(pbs_array_idx);

% Load params structure with parameter ranges necessary to study x=0, z=0
% and with limits corresponding to normal arousal states
% Default Input options to generate the file

switch pbs_idx
    case {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14}
        load('steady_state_parameters.mat', 'ssw')
        p = ssw;
        clear ssw
    case {15, 16, 17, 18, 19, 20, 21}
        load('steady_state_parameters.mat', 'ssw_mr')
        p = ssw_mr;
        clear ssw_mr
    case 42
        load('steady_state_parameters.mat', 'ssa_mr')
        p = ssa_mr;
        clear ssa_mr
        
end

switch pbs_idx
    case {1, 2, 3, 4, 5}
         inopt.interval = 1e-4;
         inopt.blocks   = 8192;
    case {8, 9, 10, 11, 12, 13, 14}
         inopt.interval = 1e-3;
         inopt.blocks   = 256;
    case {15, 16, 17, 18, 19, 20, 21}
         inopt.interval = 2^-12;
         inopt.blocks   = 1;
    case{42}
         inopt.blocks   = 256;
end

switch pbs_idx
    case 1 % A1
         fname = 'A1_1e-4';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0, 0.0] ;
    case 2 % A2
         fname = 'A2_1e-4';
         inopt.these_axes   = [1, 2, 3, 5, 7] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0] ;
    case 3 % B1
         fname = 'B1_1e-4';
         inopt.these_axes   = [3, 5, 7, 8] ; 
         inopt.slice_values = [0.0, 0.0, 0.0, p.nus(6)] ;
    case 4 % B2
         fname = 'B2_1e-4';
         inopt.these_axes   = [3, 4, 5, 8] ; 
         inopt.slice_values = [0.0, 0.0, p.nus(6), 0.0] ;
    case 5 % C1
         fname = 'C1_1e-4';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [p.nus(5), p.nus(6), p.nus(7), p.nus(8)] ;
    case 6 % C2
         fname = 'C2_1e-4';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6] ; 
         inopt.slice_values = [p.nus(7), p.nus(8)] ;
         inopt.interval = 1e-4;
         inopt.blocks   = 327949;
    case 7 % X0 % All dimensions for ec-eo states
         fname = 'X0_1e-4';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6, 7, 8] ; 
         inopt.slice_values = [] ;
         inopt.interval = 1e-4;
         inopt.blocks = 7542827;
    case 8 % A1
         fname = 'A1_1e-3';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0, 0.0] ;
    case 9 % A2
         fname = 'A2_1e-3';
         inopt.these_axes   = [1, 2, 3, 5, 7] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0] ;
    case 10 % B1
         fname = 'B1_1e-3';
         inopt.these_axes   = [3, 5, 7, 8] ; 
         inopt.slice_values = [0.0, 0.0, 0.0, p.nus(6)] ;
    case 11 % B2
         fname = 'B2_1e-3';
         inopt.these_axes   = [3, 4, 5, 8] ; 
         inopt.slice_values = [0.0, 0.0, p.nus(6), 0.0] ;
    case 12 % C1
         fname = 'C1_1e-3';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [p.nus(5), p.nus(6), p.nus(7), p.nus(8)] ;
    case 13 % C2
         fname = 'C2_1e-3';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6] ; 
         inopt.slice_values = [p.nus(7), p.nus(8)] ;
    case 14 % X0 % All dimensions for ec-eo states
         fname = 'X0_1e-3';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6, 7, 8] ; 
         inopt.slice_values = [] ;   
    case 15 % A1
         fname = 'A1_2pow-12';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0, 0.0] ;
    case 16 % A2
         fname = 'A2_2pow-12';
         inopt.these_axes   = [1, 2, 3, 5, 7] ; 
         inopt.slice_values = [0.0, p.nus(6), 0.0] ;
    case 17 % B1
         fname = 'B1_2pow-12';
         inopt.these_axes   = [3, 5, 7, 8] ; 
         inopt.slice_values = [0.0, 0.0, 0.0, p.nus(6)] ;
    case 18 % B2
         fname = 'B2_2pow-12';
         inopt.these_axes   = [3, 4, 5, 8] ; 
         inopt.slice_values = [0.0, 0.0, p.nus(6), 0.0] ;
    case 19 % C1
         fname = 'C1_2pow-12';
         inopt.these_axes   = [1, 2, 3, 4] ; 
         inopt.slice_values = [p.nus(5), p.nus(6), p.nus(7), p.nus(8)] ;
    case 20 % C2
         fname = 'C2_2pow-12';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6] ; 
         inopt.slice_values = [p.nus(7), p.nus(8)] ;
    case 21 % X0 % All dimensions for ec-eo states
         fname = 'X0_2pow-12';
         inopt.these_axes   = [1, 2, 3, 4, 5, 6, 7, 8] ; 
         inopt.slice_values = [] ;
         
    case 42 % X0 % All dimensions for ec-eo states
         fname = '-X0_variable_interval';
         % Get next power of two 
         pow2exp = min(nextpow2(p.range_nus) - 2);
         inopt.interval = 2.^pow2exp;
         inopt.these_axes   = [1, 2, 3, 4, 5, 6, 7, 8] ; 
         inopt.slice_values = [];  
end


m = utils.io.generate_matfile_options(fname, p, inopt);
%%
% Load a params structure p that has  the property 'range_nus'
parsweep.parameter_sweep(p, m)
