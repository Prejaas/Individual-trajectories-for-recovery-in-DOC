% Continues the parameter sweep from a preexisting file.
% Used in case the job is killed.
% Cases are the same as those found in script_cluster_parameter_sweep and
% the same array-pbs-launcher can be used.

% Add path to matlab
addpath(genpath('/headnode2/paula123/Code/NeuroField/corticothalamic-model'))

% Get index to switch cases if running several cases on the cluster
pbs_array_idx  = getenv('PBS_ARRAYID');
pbs_idx        = str2double(pbs_array_idx);


switch pbs_idx
    case 1 % A1
         filename = '2016-02-23_nroots_8D_SS_A1_1e-4';
    case 2 % A2
         filename = '2016-02-23_nroots_8D_SS_A2_1e-4';
    case 3 % B1
         filename = '2016-02-24_nroots_8D_SS_B1_1e-4';
    case 4 % B2
         filename = '2016-02-24_nroots_8D_SS_B2_1e-4';
    case 5 % C1
         filename = '2016-02-26_nroots_8D_SS_C1_1e-4';
    case 6 % C2
         filename = '2016-02-26_nroots_8D_SS_C2_1e-4';
    case 7 % X0 % All dimensions for ec-eo states
         filename = '2016-03-01_nroots_8D_SS_X0_1e-4';
    case 20 % C2
         filename = '2016-03-14_nroots_8D_SS_C2_2pow-12';
end


m = matfile(filename, 'Writable', true);

% This is a bit redundant
p = m.p;

% Relaunch
parsweep.parameter_sweep(p, m)
