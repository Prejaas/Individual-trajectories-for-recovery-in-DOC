% Creates a file and runs locally to test all the functions used in a 
% par(allel) parameter sweep. 
% Total runtime ~ 100 s  on Pau's laptop 
% Numworkers: 2 workers

% Load params structure
load('steady_state_parameters.mat')

% Input options to generate the file
fname = 'local_test';
inopt.interval = 0.5e-2;
inopt.blocks = 4;
inopt.these_axes   = 1:8;% explore all the dimensions
inopt.slice_values = []; % set to zero other parameters (if applicable)
inopt.pbs = [];          % cluster flag

% Generate the file
m = utils.io.generate_matfile_options(fname, ss, inopt);

% Load a params structure p that has  the property 'range_nus'
parsweep.parameter_sweep(ss, m)

% Extract some dimensions
these_axes = [1, 3, 4];
sli% these_axes = [1, 3, 4];
slice_idx  = ones(1, 5);
cube = utils.io.extract_ndimensional_dataset(m,these_axes , slice_idx);

% Plot something
options = m.options;
nus = m.nus;
data_labels = {options.axes.labels{[1, 3, 4]}};
data_ax = {nus{[1, 3, 4]}}; clear nus
utils.viz.PlotCube(cube, data_ax, data_labels)ce_idx  = ones(1, 5);
cube = utils.io.extract_ndimensional_dataset(m,these_axes , slice_idx);
% 
% % Plot something
% options = m.options;
% nus = m.nus;
% data_labels = {options.axes.labels{[1, 3, 4]}};
% data_ax = {nus{[1, 3, 4]}}; clear nus
% utils.viz.PlotCube(cube, data_ax, data_labels)
